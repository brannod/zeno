#!/usr/bin/env python3
"""Shared job, cancellation, and idle-maintenance infrastructure for Zeno."""

from __future__ import annotations

import re
import threading
import time
from collections.abc import Callable
from typing import Any

from config import MAINTENANCE_IDLE_SECONDS
from context import update_rolling_summary
from database import db_connect
from memory import auto_extract_memories, save_memory_bundle
from model_api import mark_interactive_activity, set_interactive_request_count
from settings import int_setting


# ---------------------------------------------------------------------------
# Request stop registry
# ---------------------------------------------------------------------------

_REQUEST_STOP_LOCK = threading.RLock()
_REQUEST_STOP_EVENTS: dict[str, threading.Event] = {}


def _normalize_request_id(request_id: str) -> str:
    value = str(request_id or "").strip()
    if not value:
        raise ValueError("request_id must not be empty.")
    if len(value) > 160:
        raise ValueError("request_id is too long.")
    return value


def register_request_stop(
    request_id: str,
    stop_event: threading.Event | None = None,
) -> threading.Event:
    """Register or deliberately replace one request cancellation event."""
    key = _normalize_request_id(request_id)
    event = stop_event if stop_event is not None else threading.Event()
    if not isinstance(event, threading.Event):
        raise TypeError("stop_event must be a threading.Event.")

    with _REQUEST_STOP_LOCK:
        _REQUEST_STOP_EVENTS[key] = event
    return event


def request_stop_event(request_id: str) -> threading.Event | None:
    key = _normalize_request_id(request_id)
    with _REQUEST_STOP_LOCK:
        return _REQUEST_STOP_EVENTS.get(key)


def stop_request(request_id: str) -> bool:
    """Signal a registered request without implicitly unregistering it."""
    key = _normalize_request_id(request_id)
    with _REQUEST_STOP_LOCK:
        event = _REQUEST_STOP_EVENTS.get(key)
    if event is None:
        return False
    event.set()
    return True


def unregister_request_stop(request_id: str) -> bool:
    key = _normalize_request_id(request_id)
    with _REQUEST_STOP_LOCK:
        return _REQUEST_STOP_EVENTS.pop(key, None) is not None


def request_stop_status() -> dict[str, Any]:
    with _REQUEST_STOP_LOCK:
        snapshot = list(_REQUEST_STOP_EVENTS.items())
    return {
        "total_registered": len(snapshot),
        "set_count": sum(1 for _, event in snapshot if event.is_set()),
        "request_ids": [key for key, _ in snapshot[:64]],
    }


# ---------------------------------------------------------------------------
# Per-chat generation / active-operation registry
# ---------------------------------------------------------------------------

_CHAT_OPERATION_LOCK = threading.RLock()
_CHAT_OPERATION_EVENTS: dict[int, set[threading.Event]] = {}


def _normalize_chat_id(chat_id: int) -> int:
    try:
        value = int(chat_id)
    except (TypeError, ValueError) as exc:
        raise ValueError("chat_id must be an integer.") from exc
    if value <= 0:
        raise ValueError("chat_id must be greater than zero.")
    return value


def register_chat_operation(chat_id: int, stop_event: threading.Event) -> None:
    chat_key = _normalize_chat_id(chat_id)
    if not isinstance(stop_event, threading.Event):
        raise TypeError("stop_event must be a threading.Event.")
    with _CHAT_OPERATION_LOCK:
        _CHAT_OPERATION_EVENTS.setdefault(chat_key, set()).add(stop_event)


def unregister_chat_operation(chat_id: int, stop_event: threading.Event) -> None:
    chat_key = _normalize_chat_id(chat_id)
    with _CHAT_OPERATION_LOCK:
        active = _CHAT_OPERATION_EVENTS.get(chat_key)
        if not active:
            return
        active.discard(stop_event)
        if not active:
            _CHAT_OPERATION_EVENTS.pop(chat_key, None)


def stop_chat_generation_events(chat_id: int) -> int:
    """Signal currently registered chat events and return newly-stopped count."""
    chat_key = _normalize_chat_id(chat_id)
    with _CHAT_OPERATION_LOCK:
        events = list(_CHAT_OPERATION_EVENTS.get(chat_key, set()))

    stopped = 0
    for event in events:
        if not event.is_set():
            event.set()
            stopped += 1
    return stopped


def chat_operation_status(chat_id: int | None = None) -> dict[str, Any]:
    with _CHAT_OPERATION_LOCK:
        counts = {
            int(key): len(events)
            for key, events in _CHAT_OPERATION_EVENTS.items()
            if events
        }

    result: dict[str, Any] = {
        "total_registered": sum(counts.values()),
        "active_chats": len(counts),
        "chat_ids": sorted(counts),
        "counts_by_chat": {str(key): value for key, value in sorted(counts.items())},
    }
    if chat_id is not None:
        chat_key = _normalize_chat_id(chat_id)
        result["chat_id"] = chat_key
        result["active_events"] = counts.get(chat_key, 0)
    return result


# ---------------------------------------------------------------------------
# Cross-subsystem stop hooks
# ---------------------------------------------------------------------------

_CHAT_STOP_HOOK_LOCK = threading.RLock()
_CHAT_STOP_HOOKS: dict[str, dict[str, Any]] = {}
_LAST_STOP_HOOK_ERRORS: dict[str, str] = {}


def _normalize_hook_name(name: str) -> str:
    value = re.sub(r"\s+", "_", str(name or "").strip().casefold())
    value = re.sub(r"[^a-z0-9_.-]+", "_", value).strip("_.-")
    if not value:
        raise ValueError("Stop-hook name must not be empty.")
    if len(value) > 80:
        raise ValueError("Stop-hook name is too long.")
    return value


def register_chat_stop_hook(
    name: str,
    callback: Callable[[int, str], int | dict[str, int]],
    *,
    discord_visible: bool = True,
) -> None:
    key = _normalize_hook_name(name)
    if not callable(callback):
        raise TypeError("Stop-hook callback must be callable.")

    with _CHAT_STOP_HOOK_LOCK:
        _CHAT_STOP_HOOKS[key] = {
            "callback": callback,
            "discord_visible": bool(discord_visible),
        }


def unregister_chat_stop_hook(name: str) -> bool:
    key = _normalize_hook_name(name)
    with _CHAT_STOP_HOOK_LOCK:
        _LAST_STOP_HOOK_ERRORS.pop(key, None)
        return _CHAT_STOP_HOOKS.pop(key, None) is not None


def registered_chat_stop_hooks() -> list[dict[str, Any]]:
    with _CHAT_STOP_HOOK_LOCK:
        snapshot = [
            {
                "name": name,
                "discord_visible": bool(item["discord_visible"]),
            }
            for name, item in _CHAT_STOP_HOOKS.items()
        ]
    return sorted(snapshot, key=lambda item: str(item["name"]))


def _compatibility_count_key(hook_name: str) -> str:
    folded = hook_name.casefold().replace("-", "_").replace(".", "_")
    if "deepsearch" in folded or "deep_search" in folded:
        return "deepsearch_count"
    if "file" in folded and "job" in folded:
        return "file_job_count"
    if "browser" in folded and "agent" in folded:
        return "browser_agent_count"
    return re.sub(r"[^a-z0-9_]+", "_", folded).strip("_") + "_count"


def _invoke_chat_stop_hooks(
    chat_id: int,
    reason: str,
    *,
    discord_only: bool,
) -> dict[str, int]:
    """Invoke hook callbacks without holding the registry lock."""
    with _CHAT_STOP_HOOK_LOCK:
        snapshot = [
            (name, item["callback"], bool(item["discord_visible"]))
            for name, item in _CHAT_STOP_HOOKS.items()
        ]

    counts: dict[str, int] = {}
    errors: dict[str, str] = {}

    for name, callback, discord_visible in snapshot:
        if discord_only and not discord_visible:
            continue
        try:
            raw = callback(chat_id, reason)
            if isinstance(raw, dict):
                for key, value in raw.items():
                    try:
                        numeric = max(0, int(value))
                    except (TypeError, ValueError):
                        continue
                    counts[str(key)] = counts.get(str(key), 0) + numeric
            else:
                numeric = max(0, int(raw))
                count_key = _compatibility_count_key(name)
                counts[count_key] = counts.get(count_key, 0) + numeric
        except Exception as exc:
            errors[name] = f"{type(exc).__name__}: {exc}"[:300]

    with _CHAT_STOP_HOOK_LOCK:
        for name, _callback, discord_visible in snapshot:
            if discord_only and not discord_visible:
                continue
            if name in errors:
                _LAST_STOP_HOOK_ERRORS[name] = errors[name]
            else:
                _LAST_STOP_HOOK_ERRORS.pop(name, None)

    return counts


def _stop_result_base(generation_count: int) -> dict[str, int]:
    # Keep the legacy compatibility keys stable even before future modules
    # register their stop hooks.
    return {
        "generation_count": max(0, int(generation_count)),
        "deepsearch_count": 0,
        "file_job_count": 0,
        "browser_agent_count": 0,
    }


def stop_all_chat_work(chat_id: int) -> dict[str, int]:
    chat_key = _normalize_chat_id(chat_id)
    result = _stop_result_base(stop_chat_generation_events(chat_key))
    hook_counts = _invoke_chat_stop_hooks(
        chat_key,
        "Stop All Chat Work",
        discord_only=False,
    )
    for key, value in hook_counts.items():
        result[key] = result.get(key, 0) + max(0, int(value))
    return result


def stop_discord_chat_work(chat_id: int) -> dict[str, int]:
    chat_key = _normalize_chat_id(chat_id)
    result = _stop_result_base(stop_chat_generation_events(chat_key))
    hook_counts = _invoke_chat_stop_hooks(
        chat_key,
        "Stop Discord Chat Work",
        discord_only=True,
    )
    for key, value in hook_counts.items():
        result[key] = result.get(key, 0) + max(0, int(value))
    return result


# ---------------------------------------------------------------------------
# Interactive request accounting + idle maintenance queue
# ---------------------------------------------------------------------------

_MAINTENANCE_CONDITION = threading.Condition(threading.RLock())
_MAINTENANCE_PENDING: dict[int, dict[str, Any]] = {}
_MAINTENANCE_CANCEL = threading.Event()
_MAINTENANCE_STOP = threading.Event()
_MAINTENANCE_THREAD: threading.Thread | None = None
_MAINTENANCE_ACTIVE_REQUESTS = 0
_MAINTENANCE_RUNNING_CHAT_ID = 0
_LAST_INTERACTIVE_ACTIVITY = time.monotonic()


def interactive_request_started() -> None:
    global _MAINTENANCE_ACTIVE_REQUESTS
    global _LAST_INTERACTIVE_ACTIVITY

    with _MAINTENANCE_CONDITION:
        _MAINTENANCE_ACTIVE_REQUESTS += 1
        _LAST_INTERACTIVE_ACTIVITY = time.monotonic()
        current_count = _MAINTENANCE_ACTIVE_REQUESTS
        _MAINTENANCE_CANCEL.set()
        _MAINTENANCE_CONDITION.notify_all()

    # Keep model_api's generation gate aware of user-facing activity without
    # reaching into any of its private locks/globals.
    mark_interactive_activity()
    set_interactive_request_count(current_count)


def interactive_request_finished() -> None:
    global _MAINTENANCE_ACTIVE_REQUESTS
    global _LAST_INTERACTIVE_ACTIVITY

    with _MAINTENANCE_CONDITION:
        _MAINTENANCE_ACTIVE_REQUESTS = max(
            0,
            _MAINTENANCE_ACTIVE_REQUESTS - 1,
        )
        _LAST_INTERACTIVE_ACTIVITY = time.monotonic()
        current_count = _MAINTENANCE_ACTIVE_REQUESTS
        _MAINTENANCE_CONDITION.notify_all()

    mark_interactive_activity()
    set_interactive_request_count(current_count)


def post_response_maintenance(
    chat_id: int,
    user_text: str,
    stop_event: threading.Event | None = None,
) -> bool:
    chat_key = _normalize_chat_id(chat_id)

    try:
        if stop_event is not None and stop_event.is_set():
            return False

        text = str(user_text or "").strip()
        if text and not auto_extract_memories(text, stop_event):
            return False

        if stop_event is not None and stop_event.is_set():
            return False

        if not update_rolling_summary(chat_key, stop_event):
            return False

        if stop_event is not None and stop_event.is_set():
            return False

        interval = int_setting("autosave_turn_interval", 10, 0, 100)
        if interval:
            with db_connect() as db:
                completed_turns = int(
                    db.execute(
                        "SELECT COUNT(*) FROM messages "
                        "WHERE chat_id=? AND role='assistant'",
                        (chat_key,),
                    ).fetchone()[0]
                )
            if completed_turns and completed_turns % interval == 0:
                save_memory_bundle(chat_key, "automatic checkpoint")
        return True

    except InterruptedError:
        return False
    except Exception as exc:
        print(f"Background memory maintenance failed: {exc}")
        return True


def schedule_response_maintenance(chat_id: int, user_text: str) -> None:
    chat_key = _normalize_chat_id(chat_id)
    text = str(user_text or "").strip()

    with _MAINTENANCE_CONDITION:
        pending = _MAINTENANCE_PENDING.setdefault(
            chat_key,
            {"texts": [], "due": 0.0},
        )
        if text:
            pending["texts"] = [*pending.get("texts", []), text][-8:]
        pending["due"] = time.monotonic() + MAINTENANCE_IDLE_SECONDS
        _MAINTENANCE_CONDITION.notify_all()


def maintenance_public_status() -> dict[str, Any]:
    with _MAINTENANCE_CONDITION:
        due_values = [
            float(item.get("due", 0.0))
            for item in _MAINTENANCE_PENDING.values()
        ]
        now_value = time.monotonic()
        remaining = (
            max(0, round(min(due_values) - now_value))
            if due_values
            else 0
        )
        thread = _MAINTENANCE_THREAD
        return {
            "state": (
                "running"
                if _MAINTENANCE_RUNNING_CHAT_ID
                else "waiting"
                if _MAINTENANCE_PENDING
                else "idle"
            ),
            "pending_chats": len(_MAINTENANCE_PENDING),
            "running_chat_id": _MAINTENANCE_RUNNING_CHAT_ID,
            "interactive_requests": _MAINTENANCE_ACTIVE_REQUESTS,
            "idle_delay_seconds": MAINTENANCE_IDLE_SECONDS,
            "starts_in_seconds": remaining,
            "worker_alive": bool(thread and thread.is_alive()),
            "cancel_requested": _MAINTENANCE_CANCEL.is_set(),
        }


def maintenance_worker() -> None:
    global _MAINTENANCE_RUNNING_CHAT_ID

    while not _MAINTENANCE_STOP.is_set():
        with _MAINTENANCE_CONDITION:
            task: dict[str, Any] | None = None
            chat_id = 0

            while not _MAINTENANCE_STOP.is_set():
                if not _MAINTENANCE_PENDING:
                    _MAINTENANCE_CONDITION.wait(timeout=1.0)
                    continue

                chat_id, pending = min(
                    _MAINTENANCE_PENDING.items(),
                    key=lambda item: float(item[1].get("due", 0.0)),
                )
                now_value = time.monotonic()
                idle_remaining = max(
                    float(pending.get("due", 0.0)) - now_value,
                    MAINTENANCE_IDLE_SECONDS
                    - (now_value - _LAST_INTERACTIVE_ACTIVITY),
                )

                if _MAINTENANCE_ACTIVE_REQUESTS or idle_remaining > 0:
                    wait_for = max(
                        0.25,
                        min(2.0, idle_remaining if idle_remaining > 0 else 0.5),
                    )
                    _MAINTENANCE_CONDITION.wait(timeout=wait_for)
                    continue

                task = _MAINTENANCE_PENDING.pop(chat_id)
                _MAINTENANCE_RUNNING_CHAT_ID = chat_id
                _MAINTENANCE_CANCEL.clear()
                break

            if _MAINTENANCE_STOP.is_set():
                return

        if task is None or not chat_id:
            continue

        combined_text = "\n\n".join(
            str(item)
            for item in task.get("texts", [])
            if str(item).strip()
        )[-5000:]

        try:
            completed = post_response_maintenance(
                chat_id,
                combined_text,
                _MAINTENANCE_CANCEL,
            )
        except Exception as exc:
            print(f"Idle maintenance worker failed for chat {chat_id}: {exc}")
            completed = True

        with _MAINTENANCE_CONDITION:
            _MAINTENANCE_RUNNING_CHAT_ID = 0
            if not completed and not _MAINTENANCE_STOP.is_set():
                existing = _MAINTENANCE_PENDING.setdefault(
                    chat_id,
                    {"texts": [], "due": 0.0},
                )
                existing["texts"] = [
                    *task.get("texts", []),
                    *existing.get("texts", []),
                ][-8:]
                existing["due"] = (
                    time.monotonic() + MAINTENANCE_IDLE_SECONDS
                )
            _MAINTENANCE_CONDITION.notify_all()


def start_maintenance_worker() -> None:
    global _MAINTENANCE_THREAD

    with _MAINTENANCE_CONDITION:
        if _MAINTENANCE_THREAD and _MAINTENANCE_THREAD.is_alive():
            return

        _MAINTENANCE_STOP.clear()
        _MAINTENANCE_CANCEL.clear()
        _MAINTENANCE_THREAD = threading.Thread(
            target=maintenance_worker,
            daemon=True,
            name="ZenoIdleMemory",
        )
        thread = _MAINTENANCE_THREAD

    thread.start()


def stop_maintenance_worker() -> None:
    global _MAINTENANCE_THREAD
    global _MAINTENANCE_RUNNING_CHAT_ID

    _MAINTENANCE_STOP.set()
    _MAINTENANCE_CANCEL.set()
    with _MAINTENANCE_CONDITION:
        _MAINTENANCE_CONDITION.notify_all()
        thread = _MAINTENANCE_THREAD

    if (
        thread
        and thread.is_alive()
        and thread is not threading.current_thread()
    ):
        thread.join(timeout=5.0)

    with _MAINTENANCE_CONDITION:
        if _MAINTENANCE_THREAD is thread and (
            thread is None or not thread.is_alive()
        ):
            _MAINTENANCE_THREAD = None
        if not (_MAINTENANCE_THREAD and _MAINTENANCE_THREAD.is_alive()):
            _MAINTENANCE_RUNNING_CHAT_ID = 0
        _MAINTENANCE_CONDITION.notify_all()


def jobs_status() -> dict[str, Any]:
    with _CHAT_STOP_HOOK_LOCK:
        hook_errors = dict(_LAST_STOP_HOOK_ERRORS)

    return {
        "maintenance": maintenance_public_status(),
        "request_stop_registry": request_stop_status(),
        "chat_operation_registry": chat_operation_status(),
        "registered_stop_hooks": registered_chat_stop_hooks(),
        "stop_hook_errors": hook_errors,
    }


__all__ = [
    "register_request_stop",
    "request_stop_event",
    "stop_request",
    "unregister_request_stop",
    "request_stop_status",
    "register_chat_operation",
    "unregister_chat_operation",
    "stop_chat_generation_events",
    "chat_operation_status",
    "register_chat_stop_hook",
    "unregister_chat_stop_hook",
    "registered_chat_stop_hooks",
    "stop_all_chat_work",
    "stop_discord_chat_work",
    "interactive_request_started",
    "interactive_request_finished",
    "post_response_maintenance",
    "schedule_response_maintenance",
    "maintenance_public_status",
    "maintenance_worker",
    "start_maintenance_worker",
    "stop_maintenance_worker",
    "jobs_status",
]
