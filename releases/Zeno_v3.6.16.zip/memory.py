#!/usr/bin/env python3
"""Zeno long-term memory subsystem."""

from __future__ import annotations

from collections import Counter
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
import uuid
import zipfile
from typing import Any

from config import (
    AUTO_SENSITIVE_RE,
    CHAT_MEMORY_DIR,
    CONTEXT_MEMORY_DIR,
    LM_LONG_GENERATION_TIMEOUT_SECONDS,
    LONG_TERM_MEMORY_DIR,
    MAX_RECENT_MESSAGES,
    MEMORY_CANDIDATE_LIMIT,
    MEMORY_DIR,
    MEMORY_MAX_PINNED,
    MEMORY_RETRIEVAL_LIMIT,
    SENSITIVE_RE,
)
from database import MEMORY_STOPWORDS, db_connect, now
from model_api import cancellable_completion, nonstream_completion
from settings import bool_setting, int_setting

_MEMORY_FILE_LOCK = threading.RLock()


def memory_terms(text: str) -> set[str]:
    return {
        token for token in re.findall(r"[a-z0-9][a-z0-9_+.-]{1,}", str(text or "").casefold())
        if token not in MEMORY_STOPWORDS and len(token) >= 2
    }

def memory_normalized_key(text: str) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", " ", str(text or "").casefold())
    tokens = [token for token in cleaned.split() if token not in MEMORY_STOPWORDS]
    return " ".join(tokens[:80])[:500]

def memory_category(text: str) -> str:
    value = str(text or "").casefold()
    buckets = (
        ("Zeno", ("zeno", "lm studio", "deepsearch", "discord", "browser agent", "file worker")),
        ("Files", ("csv", "xlsx", "spreadsheet", "file", "txt", "json", "proxy", "aycd")),
        ("Code", ("python", "javascript", "html", "css", "code", "api", "script")),
        ("Trading", ("trading", "futures", "stock", "topstep", "gold", "market")),
        ("Preferences", ("prefers", "preference", "likes", "wants", "doesn't want", "does not want")),
        ("People", ("friend", "mother", "partner", "coworker", "person")),
        ("Projects", ("project", "roadmap", "build", "workflow", "setup")),
    )
    for category, terms in buckets:
        if any(term in value for term in terms):
            return category
    return "General"

def memory_temperature(row: dict[str, Any] | sqlite3.Row, current_time: int | None = None) -> str:
    keys = set(row.keys())
    now_value = int(current_time or now())
    pinned = bool(int(row["pinned"] or 0)) if "pinned" in keys else False
    access_count = int(row["access_count"] or 0) if "access_count" in keys else 0
    last_used = int(row["last_used_at"] or 0) if "last_used_at" in keys else 0
    updated = int(row["updated_at"] or row["created_at"] or 0) if "updated_at" in keys else 0
    age = now_value - max(last_used, updated)
    if pinned or access_count >= 5 or age <= 7 * 86400:
        return "hot"
    if access_count >= 1 or age <= 90 * 86400:
        return "warm"
    return "cold"

def memory_relevance_score(query: str, row: sqlite3.Row) -> float:
    query_terms = memory_terms(query)
    memory_set = memory_terms(str(row["content"] or ""))
    overlap = len(query_terms & memory_set) if query_terms and memory_set else 0
    if not query_terms or not overlap:
        return 0.0
    score = overlap * 4.0
    score += overlap / max(1, len(query_terms)) * 5.0
    score += overlap / max(1, len(memory_set)) * 2.0
    # Pinning is a retention/ranking hint, not permission to inject an unrelated memory.
    if bool(int(row["pinned"] or 0)):
        score += 3.0
    score += min(2.0, int(row["access_count"] or 0) * 0.20)
    anchor = max(int(row["last_used_at"] or 0), int(row["updated_at"] or 0), int(row["created_at"] or 0))
    age_days = max(0.0, (now() - anchor) / 86400.0)
    if age_days <= 7:
        score += 1.0
    elif age_days <= 45:
        score += 0.35
    return score

def retrieve_relevant_memories(query: str, limit: int | None = None, touch: bool = True) -> list[dict[str, Any]]:
    actual_limit = max(3, min(int(limit or int_setting("memory_retrieval_limit", MEMORY_RETRIEVAL_LIMIT, 3, 30)), 30))
    if not bool_setting("memory_retrieval_enabled", True):
        return []
    query_terms = memory_terms(query)
    if not query_terms:
        return []
    with db_connect() as db:
        rows = db.execute(
            "SELECT * FROM memories ORDER BY pinned DESC,updated_at DESC LIMIT ?", (MEMORY_CANDIDATE_LIMIT,)
        ).fetchall()
    ranked = sorted(((memory_relevance_score(query, row), row) for row in rows), key=lambda pair: pair[0], reverse=True)
    selected = []
    pinned_seen = 0
    for score, row in ranked:
        if score <= 0:
            continue
        # Require direct lexical relevance. Recency/access/pinning can only rank relevant rows.
        if not (query_terms & memory_terms(str(row["content"] or ""))):
            continue
        pinned = bool(int(row["pinned"] or 0))
        if pinned:
            if pinned_seen >= MEMORY_MAX_PINNED:
                continue
            pinned_seen += 1
        selected.append(row)
        if len(selected) >= actual_limit:
            break
    if touch and selected:
        ids = [int(row["id"]) for row in selected]
        with db_connect() as db:
            placeholders = ",".join("?" for _ in ids)
            db.execute(
                f"UPDATE memories SET access_count=access_count+1,last_used_at=? WHERE id IN ({placeholders})",
                (now(), *ids),
            )
    return [dict(row) | {"temperature": memory_temperature(row)} for row in selected]

def memory_is_near_duplicate(candidate: str, existing_rows: list[sqlite3.Row]) -> sqlite3.Row | None:
    candidate_key = memory_normalized_key(candidate)
    candidate_terms = memory_terms(candidate)
    for row in existing_rows:
        existing_key = str(row["normalized_key"] or memory_normalized_key(str(row["content"])))
        if candidate_key and candidate_key == existing_key:
            return row
        existing_terms = memory_terms(str(row["content"]))
        if not candidate_terms or not existing_terms:
            continue
        overlap = len(candidate_terms & existing_terms)
        union = candidate_terms | existing_terms
        similarity = overlap / max(1, len(union))
        containment = overlap / max(1, min(len(candidate_terms), len(existing_terms)))
        if similarity >= 0.72 or containment >= 0.90:
            return row
    return None

def safe_json_list(raw: str) -> list[str]:
    match = re.search(r"\[[\s\S]*\]", raw)
    if not match:
        return []
    try:
        value = json.loads(match.group(0))
        return [str(item).strip() for item in value if isinstance(item, str) and str(item).strip()]
    except (json.JSONDecodeError, TypeError):
        return []

def contains_sensitive_memory(text: str) -> bool:
    if SENSITIVE_RE.search(text):
        return True
    if re.search(r"\b(?:\d[ -]*?){13,19}\b", text):
        return True
    if re.search(r"\b[A-Za-z0-9+/]{28,}={0,2}\b", text):
        return True
    return False

def auto_extract_memories(user_text: str, stop_event: threading.Event | None = None) -> bool:
    if (not bool_setting("auto_memory", True) or contains_sensitive_memory(user_text)
            or AUTO_SENSITIVE_RE.search(user_text)):
        return True
    prompt = [
        {"role": "system", "content": (
            "Extract only durable, useful user facts or preferences worth remembering across future chats. "
            "Do not save passwords, codes, keys, tokens, financial account details, medical secrets, addresses, "
            "or transient requests. Return a JSON array of short standalone strings. Return [] when nothing qualifies."
        )},
        {"role": "user", "content": user_text[:5000]},
    ]
    try:
        if stop_event is None:
            raw = nonstream_completion(prompt, max_tokens=350, temperature=0.0, model_mode="fast")
        else:
            raw = cancellable_completion(
                prompt, stop_event, max_tokens=350, temperature=0.0, request_class="maintenance",
                idle_only=True, yield_to_higher_priority=True,
            )
        candidates = safe_json_list(raw)[:4]
    except InterruptedError:
        return False
    except Exception as exc:
        print(f"Automatic memory skipped: {exc}")
        return True
    with db_connect() as db:
        existing_rows = db.execute("SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?", (MEMORY_CANDIDATE_LIMIT,)).fetchall()
        for item in candidates:
            item = re.sub(r"\s+", " ", item).strip()[:400]
            if len(item) < 5 or contains_sensitive_memory(item) or AUTO_SENSITIVE_RE.search(item):
                continue
            duplicate = memory_is_near_duplicate(item, list(existing_rows))
            if duplicate:
                db.execute("UPDATE memories SET updated_at=? WHERE id=?", (now(), int(duplicate["id"])))
                continue
            cursor = db.execute(
                "INSERT INTO memories(content,created_at,updated_at,source,category,normalized_key) VALUES(?,?,?,'auto',?,?)",
                (item, now(), now(), memory_category(item), memory_normalized_key(item)),
            )
            existing_rows = [*existing_rows, db.execute("SELECT * FROM memories WHERE id=?", (int(cursor.lastrowid),)).fetchone()]
    return True

def manual_context_to_memory(chat_id: int, stop_event: threading.Event | None = None) -> dict[str, Any]:
    """Summarize the current shared chat and promote durable, non-sensitive facts into long-term memory."""
    stop_event = stop_event or threading.Event()
    with db_connect() as db:
        chat = db.execute("SELECT id,title,summary FROM chats WHERE id=?", (chat_id,)).fetchone()
        if not chat:
            raise ValueError("That Zeno chat no longer exists.")
        rows = db.execute(
            "SELECT id,role,content,source,source_label FROM messages WHERE chat_id=? ORDER BY id", (chat_id,)
        ).fetchall()
    if not rows:
        return {"messages": 0, "added": 0, "refreshed": 0, "summary": str(chat["summary"] or "")}

    # Stage 1: summarize the full transcript in bounded chunks so !context works on long-running chats.
    chunk_summaries: list[str] = []
    current: list[str] = []
    current_chars = 0
    for row in rows:
        role = str(row["role"] or "message").upper()
        if str(row["source"] or "") == "discord" and str(row["source_label"] or "").strip():
            role += f" [Discord | {str(row['source_label'])[:80]}]"
        line = f"{role}: {str(row['content'] or '')[:3500]}"
        if current and (current_chars + len(line) > 18000 or len(current) >= 28):
            transcript = "\n".join(current)
            prompt = [
                {"role": "system", "content": (
                    "Summarize this portion of a Zeno shared chat for durable continuity. Preserve concrete decisions, "
                    "user preferences, project state, corrections, current configuration, unresolved work, useful file/web findings, "
                    "and explicit constraints. Do not invent details. Do not preserve passwords, tokens, OTPs, payment data, "
                    "private credentials, or other secrets. Use compact factual bullets."
                )},
                {"role": "user", "content": transcript},
            ]
            chunk_summaries.append(cancellable_completion(
                prompt, stop_event, max_tokens=700, temperature=0.1,
                timeout_seconds=LM_LONG_GENERATION_TIMEOUT_SECONDS, request_class="interactive",
            ))
            if stop_event.is_set():
                raise InterruptedError("Context save was stopped.")
            current, current_chars = [], 0
        current.append(line)
        current_chars += len(line)
    if current:
        transcript = "\n".join(current)
        prompt = [
            {"role": "system", "content": (
                "Summarize this portion of a Zeno shared chat for durable continuity. Preserve concrete decisions, "
                "user preferences, project state, corrections, current configuration, unresolved work, useful file/web findings, "
                "and explicit constraints. Do not invent details. Do not preserve passwords, tokens, OTPs, payment data, "
                "private credentials, or other secrets. Use compact factual bullets."
            )},
            {"role": "user", "content": transcript},
        ]
        chunk_summaries.append(cancellable_completion(
                prompt, stop_event, max_tokens=700, temperature=0.1,
                timeout_seconds=LM_LONG_GENERATION_TIMEOUT_SECONDS, request_class="interactive",
            ))

    if stop_event.is_set():
        raise InterruptedError("Context save was stopped.")

    # Stage 2: consolidate all chunk summaries plus the previous rolling summary into one current context summary.
    combined = "\n\n".join(f"PART {i+1}:\n{x}" for i, x in enumerate(chunk_summaries))
    final_prompt = [
        {"role": "system", "content": (
            "Create one compact master context summary for Zeno. Keep only factual continuity that will matter later: "
            "decisions, preferences, project roadmap/state, settings, corrections, active constraints, unresolved tasks, and important findings. "
            "Resolve duplicate statements in favor of the newest correction. Do not include passwords, tokens, OTPs, payment details, "
            "or sensitive credentials. Use concise bullets with clear topic labels."
        )},
        {"role": "user", "content": (
            f"Previous rolling summary:\n{str(chat['summary'] or '(none)')[:9000]}\n\n"
            f"Full-chat chunk summaries:\n{combined[:52000]}"
        )},
    ]
    master_summary = cancellable_completion(
        final_prompt, stop_event, max_tokens=1400, temperature=0.1,
        timeout_seconds=LM_LONG_GENERATION_TIMEOUT_SECONDS, request_class="interactive",
    ).strip()
    if not master_summary:
        raise RuntimeError("Zeno could not produce a context summary.")

    # Keep the newest messages live in prompt context while also storing the complete master summary.
    keep_recent = min(12, len(rows))
    summary_until_id = int(rows[-keep_recent-1]["id"]) if len(rows) > keep_recent else 0
    with db_connect() as db:
        db.execute(
            "UPDATE chats SET summary=?,summary_until_id=?,updated_at=? WHERE id=?",
            (master_summary[:12000], summary_until_id, now(), chat_id),
        )

    # Stage 3: extract discrete durable memories. This makes Memory 2.0 retrieval useful without injecting one giant blob.
    memory_prompt = [
        {"role": "system", "content": (
            "From the context summary, extract up to 16 durable standalone memories worth recalling in future chats. "
            "Prefer explicit user preferences, project decisions, configurations, recurring constraints, and unresolved goals. "
            "Skip transient conversation details and anything sensitive. Never include passwords, tokens, keys, OTPs, payment-card data, "
            "or private credentials. Return ONLY a JSON array of short strings."
        )},
        {"role": "user", "content": master_summary[:12000]},
    ]
    raw_memories = cancellable_completion(
        memory_prompt, stop_event, max_tokens=900, temperature=0.0,
        timeout_seconds=LM_LONG_GENERATION_TIMEOUT_SECONDS, request_class="interactive",
    )
    candidates = safe_json_list(raw_memories)[:16]
    added = 0
    refreshed = 0
    with db_connect() as db:
        existing_rows = db.execute(
            "SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?", (MEMORY_CANDIDATE_LIMIT,)
        ).fetchall()
        for item in candidates:
            item = re.sub(r"\s+", " ", str(item or "")).strip()[:700]
            if len(item) < 5 or contains_sensitive_memory(item) or AUTO_SENSITIVE_RE.search(item):
                continue
            duplicate = memory_is_near_duplicate(item, list(existing_rows))
            if duplicate:
                db.execute("UPDATE memories SET updated_at=?,source='context' WHERE id=?", (now(), int(duplicate["id"])))
                refreshed += 1
                continue
            cursor = db.execute(
                "INSERT INTO memories(content,created_at,updated_at,source,category,normalized_key) VALUES(?,?,?,'context',?,?)",
                (item, now(), now(), memory_category(item), memory_normalized_key(item)),
            )
            new_row = db.execute("SELECT * FROM memories WHERE id=?", (int(cursor.lastrowid),)).fetchone()
            existing_rows = [*existing_rows, new_row]
            added += 1

    save_memory_bundle(chat_id, "manual !context consolidation")
    return {
        "messages": len(rows), "added": added, "refreshed": refreshed,
        "summary": master_summary[:12000], "chunks": len(chunk_summaries),
    }

def memory_stats(query: str = "") -> dict[str, Any]:
    """Return memory-bank counters without materializing the whole table."""
    current = now()
    hot_cutoff = current - 7 * 86400
    warm_cutoff = current - 90 * 86400
    with db_connect() as db:
        row = db.execute(
            "SELECT COUNT(*) total, "
            "SUM(CASE WHEN pinned=1 OR access_count>=5 OR MAX(last_used_at,updated_at)>=? THEN 1 ELSE 0 END) hot, "
            "SUM(CASE WHEN NOT (pinned=1 OR access_count>=5 OR MAX(last_used_at,updated_at)>=?) "
            "AND (access_count>=1 OR MAX(last_used_at,updated_at)>=?) THEN 1 ELSE 0 END) warm, "
            "SUM(CASE WHEN NOT (pinned=1 OR access_count>=5 OR MAX(last_used_at,updated_at)>=?) "
            "AND NOT (access_count>=1 OR MAX(last_used_at,updated_at)>=?) THEN 1 ELSE 0 END) cold, "
            "SUM(CASE WHEN pinned=1 THEN 1 ELSE 0 END) pinned_count FROM memories",
            (hot_cutoff, hot_cutoff, warm_cutoff, hot_cutoff, warm_cutoff),
        ).fetchone()
    preview = retrieve_relevant_memories(query or "current conversation", touch=False)
    return {
        "total": int(row["total"] or 0), "hot": int(row["hot"] or 0),
        "warm": int(row["warm"] or 0), "cold": int(row["cold"] or 0),
        "pinned": int(row["pinned_count"] or 0),
        "retrieval_enabled": bool_setting("memory_retrieval_enabled", True),
        "retrieval_limit": int_setting("memory_retrieval_limit", MEMORY_RETRIEVAL_LIMIT, 3, 30),
        "preview_ids": [int(item["id"]) for item in preview],
    }


def json_load(value: str, fallback: Any) -> Any:
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return fallback

def _atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def _normalize_memory_content(content: str) -> str:
    value = re.sub(r"\s+", " ", str(content or "")).strip()
    if not value or len(value) > 2000:
        raise ValueError("Memory content must be between 1 and 2000 characters.")
    if contains_sensitive_memory(value):
        raise ValueError("Sensitive credentials or secret-like data cannot be saved as memory.")
    return value


def _safe_source_identifier(source: str) -> str:
    value = re.sub(r"[^a-z0-9_.-]+", "-", str(source or "manual").strip().casefold())
    value = value.strip("-.")[:40]
    return value or "manual"


def _memory_row_to_dict(
    row: sqlite3.Row,
    *,
    include_temperature: bool = True,
) -> dict[str, Any]:
    item = dict(row)
    if "pinned" in item:
        item["pinned"] = bool(item["pinned"])
    if include_temperature:
        item["temperature"] = memory_temperature(row)
    return item


def list_memories(
    *,
    query: str = "",
    include_temperature: bool = True,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """List memories with an optional UI-facing limit.

    Retrieval/ranking behavior elsewhere is unchanged. For the common unfiltered
    GUI view, applying LIMIT in SQLite avoids materializing an arbitrarily large
    memory bank on every /api/state refresh.
    """
    requested_limit = None if limit is None else max(1, min(int(limit), 5000))
    query_text = str(query or "").strip()
    with db_connect() as db:
        if requested_limit is not None and not query_text:
            rows = db.execute(
                "SELECT * FROM memories ORDER BY pinned DESC,updated_at DESC LIMIT ?",
                (requested_limit,),
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM memories ORDER BY pinned DESC,updated_at DESC"
            ).fetchall()

    if query_text:
        rows = sorted(
            rows,
            key=lambda row: (memory_relevance_score(query_text, row), int(row["id"])),
            reverse=True,
        )
        if requested_limit is not None:
            rows = rows[:requested_limit]

    return [
        _memory_row_to_dict(row, include_temperature=include_temperature)
        for row in rows
    ]


def add_memory(
    content: str,
    *,
    chat_id: int | None = None,
    source: str = "manual",
) -> dict[str, Any]:
    value = _normalize_memory_content(content)
    source_id = _safe_source_identifier(source)

    with db_connect() as db:
        existing_rows = db.execute(
            "SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?",
            (MEMORY_CANDIDATE_LIMIT,),
        ).fetchall()
        duplicate = memory_is_near_duplicate(value, list(existing_rows))

        if duplicate is not None:
            memory_id = int(duplicate["id"])
            db.execute(
                "UPDATE memories SET updated_at=? WHERE id=?",
                (now(), memory_id),
            )
            row = db.execute(
                "SELECT * FROM memories WHERE id=?",
                (memory_id,),
            ).fetchone()
            result = _memory_row_to_dict(row)
            result["duplicate"] = True
        else:
            timestamp = now()
            cursor = db.execute(
                "INSERT INTO memories(content,created_at,updated_at,source,category,normalized_key) "
                "VALUES(?,?,?,?,?,?)",
                (
                    value,
                    timestamp,
                    timestamp,
                    source_id,
                    memory_category(value),
                    memory_normalized_key(value),
                ),
            )
            memory_id = int(cursor.lastrowid)
            row = db.execute(
                "SELECT * FROM memories WHERE id=?",
                (memory_id,),
            ).fetchone()
            result = _memory_row_to_dict(row)
            result["duplicate"] = False

    if chat_id is not None:
        save_memory_bundle(int(chat_id), "memory updated")
    return result


def edit_memory(
    memory_id: int,
    content: str,
    *,
    chat_id: int | None = None,
) -> dict[str, Any]:
    value = _normalize_memory_content(content)
    memory_id = int(memory_id)

    with db_connect() as db:
        row = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()
        if row is None:
            raise ValueError("Memory not found.")

        db.execute(
            "UPDATE memories SET content=?,updated_at=?,category=?,normalized_key=? WHERE id=?",
            (
                value,
                now(),
                memory_category(value),
                memory_normalized_key(value),
                memory_id,
            ),
        )
        updated = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()

    if chat_id is not None:
        save_memory_bundle(int(chat_id), "memory updated")
    return _memory_row_to_dict(updated)


def pin_memory(memory_id: int, pinned: bool) -> dict[str, Any]:
    memory_id = int(memory_id)
    target = bool(pinned)

    with db_connect() as db:
        row = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()
        if row is None:
            raise ValueError("Memory not found.")

        if target:
            pinned_count = int(
                db.execute(
                    "SELECT COUNT(*) FROM memories WHERE pinned=1 AND id!=?",
                    (memory_id,),
                ).fetchone()[0]
            )
            if pinned_count >= MEMORY_MAX_PINNED:
                raise ValueError(
                    f"Zeno supports at most {MEMORY_MAX_PINNED} pinned memories."
                )

        db.execute(
            "UPDATE memories SET pinned=?,updated_at=? WHERE id=?",
            (1 if target else 0, now(), memory_id),
        )
        updated = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()

    return _memory_row_to_dict(updated)


def set_memory_temperature(memory_id: int, temperature: str) -> dict[str, Any]:
    memory_id = int(memory_id)
    target = str(temperature or "").strip().casefold()
    if target not in {"hot", "warm", "cold"}:
        raise ValueError("Memory temperature must be hot, warm, or cold.")

    timestamp = now()
    with db_connect() as db:
        row = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()
        if row is None:
            raise ValueError("Memory not found.")

        if target == "hot":
            db.execute(
                "UPDATE memories SET access_count=MAX(access_count,5),"
                "last_used_at=?,updated_at=? WHERE id=?",
                (timestamp, timestamp, memory_id),
            )
        elif target == "warm":
            warm_time = timestamp - 10 * 86400
            db.execute(
                "UPDATE memories SET access_count=MAX(access_count,1),"
                "last_used_at=?,updated_at=? WHERE id=?",
                (warm_time, warm_time, memory_id),
            )
        else:
            cold_time = timestamp - 120 * 86400
            db.execute(
                "UPDATE memories SET pinned=0,access_count=0,last_used_at=0,"
                "updated_at=MIN(updated_at,?) WHERE id=?",
                (cold_time, memory_id),
            )

        updated = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()

    return _memory_row_to_dict(updated)


def delete_memory(
    memory_id: int,
    *,
    chat_id: int | None = None,
) -> dict[str, Any]:
    memory_id = int(memory_id)

    with db_connect() as db:
        row = db.execute(
            "SELECT * FROM memories WHERE id=?",
            (memory_id,),
        ).fetchone()
        if row is None:
            raise ValueError("Memory not found.")
        deleted = _memory_row_to_dict(row)
        db.execute("DELETE FROM memories WHERE id=?", (memory_id,))

    if chat_id is not None:
        save_memory_bundle(int(chat_id), "memory updated")
    return {"deleted": True, "memory": deleted}



def _memory_pair_similarity(a: str, b: str) -> tuple[float, float]:
    a_terms = memory_terms(a)
    b_terms = memory_terms(b)
    if not a_terms or not b_terms:
        return 0.0, 0.0
    overlap = len(a_terms & b_terms)
    union = len(a_terms | b_terms)
    similarity = overlap / max(1, union)
    containment = overlap / max(1, min(len(a_terms), len(b_terms)))
    return similarity, containment


def analyze_memory_bank(limit: int = 1200) -> dict[str, Any]:
    """Find conservative duplicate candidates without changing the database."""
    cap = max(50, min(int(limit or 1200), 3000))
    with db_connect() as db:
        rows = db.execute(
            "SELECT * FROM memories ORDER BY pinned DESC,LENGTH(content) DESC,updated_at DESC,id DESC LIMIT ?",
            (cap,),
        ).fetchall()

    canonical: list[sqlite3.Row] = []
    groups: dict[int, dict[str, Any]] = {}
    duplicate_count = 0
    for row in rows:
        content = str(row["content"] or "")
        key = str(row["normalized_key"] or memory_normalized_key(content))
        match = None
        reason = ""
        score = 0.0
        for kept in canonical:
            kept_content = str(kept["content"] or "")
            kept_key = str(kept["normalized_key"] or memory_normalized_key(kept_content))
            if key and key == kept_key:
                match, reason, score = kept, "same normalized key", 1.0
                break
            similarity, containment = _memory_pair_similarity(content, kept_content)
            # Analysis is a little broader than deletion so the user can review
            # possible duplicates that Zeno deliberately refuses to auto-delete.
            if similarity >= 0.78 or containment >= 0.94:
                match, reason, score = kept, "very similar wording", max(similarity, containment)
                break
        if match is None:
            canonical.append(row)
            continue
        duplicate_count += 1
        kept_id = int(match["id"])
        group = groups.setdefault(kept_id, {
            "keep": _memory_row_to_dict(match),
            "duplicates": [],
        })
        duplicate = _memory_row_to_dict(row)
        duplicate["reason"] = reason
        duplicate["similarity"] = round(score, 3)
        group["duplicates"].append(duplicate)

    ordered = sorted(groups.values(), key=lambda group: len(group["duplicates"]), reverse=True)
    return {
        "scanned": len(rows),
        "duplicate_count": duplicate_count,
        "groups": ordered[:100],
        "truncated": len(rows) >= cap,
    }


def optimize_memory_bank(*, dry_run: bool = False, limit: int = 2000) -> dict[str, Any]:
    """Conservatively merge strong duplicates while preserving the richest row.

    The operation never asks a model to rewrite memories. It only removes rows
    whose token overlap is strong enough to be considered duplicates, preserving
    pin/access/recency metadata on the retained canonical row.
    """
    cap = max(50, min(int(limit or 2000), 5000))
    with db_connect() as db:
        rows = db.execute(
            "SELECT * FROM memories ORDER BY pinned DESC,LENGTH(content) DESC,updated_at DESC,id DESC LIMIT ?",
            (cap,),
        ).fetchall()

    canonical: list[sqlite3.Row] = []
    merges: list[dict[str, Any]] = []
    for row in rows:
        content = str(row["content"] or "")
        key = str(row["normalized_key"] or memory_normalized_key(content))
        match = None
        score = 0.0
        for kept in canonical:
            kept_content = str(kept["content"] or "")
            kept_key = str(kept["normalized_key"] or memory_normalized_key(kept_content))
            if key and key == kept_key:
                match, score = kept, 1.0
                break
            similarity, containment = _memory_pair_similarity(content, kept_content)
            # Auto-merge threshold is intentionally stricter than analysis.
            if similarity >= 0.86 or containment >= 0.97:
                match, score = kept, max(similarity, containment)
                break
        if match is None:
            canonical.append(row)
            continue
        merges.append({
            "keep_id": int(match["id"]),
            "remove_id": int(row["id"]),
            "similarity": round(score, 3),
            "keep": str(match["content"] or "")[:500],
            "remove": content[:500],
        })

    if not dry_run and merges:
        with db_connect() as db:
            for item in merges:
                keep = db.execute("SELECT * FROM memories WHERE id=?", (item["keep_id"],)).fetchone()
                remove = db.execute("SELECT * FROM memories WHERE id=?", (item["remove_id"],)).fetchone()
                if keep is None or remove is None:
                    continue
                db.execute(
                    "UPDATE memories SET pinned=?,access_count=?,last_used_at=?,updated_at=? WHERE id=?",
                    (
                        1 if bool(keep["pinned"]) or bool(remove["pinned"]) else 0,
                        max(int(keep["access_count"] or 0), int(remove["access_count"] or 0)),
                        max(int(keep["last_used_at"] or 0), int(remove["last_used_at"] or 0)),
                        max(int(keep["updated_at"] or 0), int(remove["updated_at"] or 0)),
                        int(keep["id"]),
                    ),
                )
                db.execute("DELETE FROM memories WHERE id=?", (int(remove["id"]),))

    return {
        "dry_run": bool(dry_run),
        "scanned": len(rows),
        "merged": 0 if dry_run else len(merges),
        "candidates": len(merges),
        "merges": merges[:100],
        "remaining": memory_stats("").get("total", 0) if not dry_run else memory_stats("").get("total", 0),
    }


def save_memory_bundle(
    chat_id: int | None = None,
    reason: str = "manual save",
) -> dict[str, Any]:
    with _MEMORY_FILE_LOCK:
        saved_at = now()

        with db_connect() as db:
            if chat_id is None:
                chat_rows = db.execute("SELECT * FROM chats ORDER BY id").fetchall()
            else:
                chat_rows = db.execute(
                    "SELECT * FROM chats WHERE id=?",
                    (int(chat_id),),
                ).fetchall()

            memories = []
            for row in db.execute(
                "SELECT id,content,source,category,pinned,access_count,last_used_at,"
                "normalized_key,created_at,updated_at "
                "FROM memories ORDER BY pinned DESC,updated_at DESC"
            ):
                item = dict(row)
                item["pinned"] = bool(item["pinned"])
                item["temperature"] = memory_temperature(row)
                memories.append(item)

            chat_payloads = []
            for chat in chat_rows:
                messages = []
                for row in db.execute(
                    "SELECT id,role,content,created_at,attachments_json,citations_json,"
                    "source,source_label,external_id FROM messages "
                    "WHERE chat_id=? ORDER BY id",
                    (int(chat["id"]),),
                ):
                    item = dict(row)
                    item["attachments"] = json_load(item.pop("attachments_json"), [])
                    item["citations"] = json_load(item.pop("citations_json"), [])
                    messages.append(item)
                chat_payloads.append((dict(chat), messages))

        recent_limit = int_setting(
            "recent_context_messages",
            MAX_RECENT_MESSAGES,
            6,
            80,
        )
        saved_chats: list[int] = []

        for chat, messages in chat_payloads:
            chat_id_value = int(chat["id"])
            chat_json = {
                "format": "Zeno chat checkpoint v1",
                "saved_at": saved_at,
                "reason": reason,
                "chat": chat,
                "messages": messages,
            }
            _atomic_write_text(
                CHAT_MEMORY_DIR / f"chat_{chat_id_value:06d}.json",
                json.dumps(chat_json, ensure_ascii=False, indent=2),
            )

            recent = messages[-recent_limit:]

            def checkpoint_speaker(item: dict[str, Any]) -> str:
                if (
                    str(item.get("role")) == "user"
                    and str(item.get("source")) == "discord"
                    and str(item.get("source_label") or "").strip()
                ):
                    return f"Discord · {str(item['source_label'])[:80]}"
                return str(item.get("role", "message")).title()

            recent_text = "\n\n".join(
                f"### {checkpoint_speaker(item)}\n\n{item['content']}"
                for item in recent
            ) or "No messages yet."

            context_text = (
                f"# {chat['title']}\n\n"
                f"Saved by Zeno at "
                f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(saved_at))}.\n\n"
                f"## Rolling summary\n\n"
                f"{chat.get('summary') or 'No rolling summary yet.'}\n\n"
                f"## Recent context ({len(recent)} messages)\n\n"
                f"{recent_text}\n"
            )
            _atomic_write_text(
                CONTEXT_MEMORY_DIR / f"context_{chat_id_value:06d}.md",
                context_text,
            )
            saved_chats.append(chat_id_value)

        _atomic_write_text(
            LONG_TERM_MEMORY_DIR / "memories.json",
            json.dumps(
                {
                    "format": "Zeno long-term memory v1",
                    "saved_at": saved_at,
                    "memories": memories,
                },
                ensure_ascii=False,
                indent=2,
            ),
        )

        index = {
            "format": "Zeno memory index v1",
            "saved_at": saved_at,
            "reason": reason,
            "database": "zeno.db",
            "chat_ids": saved_chats,
            "folders": {
                "chat_history": "chats",
                "context": "context",
                "long_term_memory": "long_term",
            },
        }
        _atomic_write_text(
            MEMORY_DIR / "index.json",
            json.dumps(index, ensure_ascii=False, indent=2),
        )

        return {
            "saved_at": saved_at,
            "chat_ids": saved_chats,
            "memory_folder": str(MEMORY_DIR),
        }


def memory_export_zip(chat_id: int) -> bytes:
    with _MEMORY_FILE_LOCK:
        save_memory_bundle(int(chat_id), "memory export")
        backup_path = MEMORY_DIR / f".zeno-export-{uuid.uuid4().hex}.db"

        try:
            source = db_connect()
            target = sqlite3.connect(backup_path)
            try:
                source.backup(target)
            finally:
                target.close()
                source.close()

            output = io.BytesIO()
            with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.write(backup_path, "memory/zeno.db")

                for folder in (
                    CHAT_MEMORY_DIR,
                    CONTEXT_MEMORY_DIR,
                    LONG_TERM_MEMORY_DIR,
                ):
                    if not folder.exists():
                        continue
                    for path in folder.rglob("*"):
                        if path.is_file() and not path.name.endswith(".tmp"):
                            archive.write(
                                path,
                                str(Path("memory") / path.relative_to(MEMORY_DIR)),
                            )

                index_path = MEMORY_DIR / "index.json"
                if index_path.exists():
                    archive.write(index_path, "memory/index.json")

            return output.getvalue()
        finally:
            backup_path.unlink(missing_ok=True)




# ZENO_AGENT_AUTOMATION_PACK_2026_08_28: conservative Memory Optimizer

def _memory_optimizer_duplicate(a: dict[str, Any], b: dict[str, Any]) -> bool:
    a_content = str(a.get("content") or "")
    b_content = str(b.get("content") or "")
    a_key = str(a.get("normalized_key") or memory_normalized_key(a_content))
    b_key = str(b.get("normalized_key") or memory_normalized_key(b_content))
    if a_key and a_key == b_key:
        return True
    a_terms = memory_terms(a_content)
    b_terms = memory_terms(b_content)
    if min(len(a_terms), len(b_terms)) < 4:
        return False
    # Do not merge memories that carry different explicit numeric/version facts.
    a_numbers = set(re.findall(r"\b\d+(?:\.\d+)*\b", a_content))
    b_numbers = set(re.findall(r"\b\d+(?:\.\d+)*\b", b_content))
    if a_numbers and b_numbers and a_numbers != b_numbers:
        return False
    overlap = len(a_terms & b_terms)
    if overlap < 4:
        return False
    union = len(a_terms | b_terms)
    jaccard = overlap / max(1, union)
    containment = overlap / max(1, min(len(a_terms), len(b_terms)))
    return jaccard >= 0.86 or containment >= 0.97


def optimize_memories(chat_id: int, *, dry_run: bool = True, limit: int = 5000) -> dict[str, Any]:
    """Preview or merge only high-confidence duplicate long-term memories.

    Pinned state, access counts and most-recent timestamps are preserved on the
    surviving record. No model calls are used, and stale-but-unique memories are
    never deleted merely for being old.
    """
    limit = max(10, min(int(limit or 5000), 10000))
    with db_connect() as db:
        rows = [dict(row) for row in db.execute(
            "SELECT * FROM memories ORDER BY pinned DESC,updated_at DESC,id DESC LIMIT ?", (limit,)
        ).fetchall()]
    if not rows:
        return {"scanned": 0, "duplicate_groups": 0, "duplicates": 0, "repairs": 0, "dry_run": bool(dry_run), "preview": []}

    parent = list(range(len(rows)))
    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    exact: dict[str, int] = {}
    for i, row in enumerate(rows):
        key = str(row.get("normalized_key") or memory_normalized_key(str(row.get("content") or "")))
        if key:
            if key in exact:
                union(i, exact[key])
            else:
                exact[key] = i

    # Bounded high-confidence near-duplicate pass.
    for i, left in enumerate(rows):
        for j in range(i + 1, len(rows)):
            if find(i) == find(j):
                continue
            right = rows[j]
            if _memory_optimizer_duplicate(left, right):
                union(i, j)

    groups: dict[int, list[dict[str, Any]]] = {}
    for i, row in enumerate(rows):
        groups.setdefault(find(i), []).append(row)
    dup_groups = [group for group in groups.values() if len(group) > 1]

    def winner_key(row: dict[str, Any]) -> tuple[int, int, int, int, int, int]:
        return (
            int(row.get("pinned") or 0),
            int(row.get("access_count") or 0),
            int(row.get("last_used_at") or 0),
            int(row.get("updated_at") or 0),
            len(str(row.get("content") or "")),
            int(row.get("id") or 0),
        )

    preview = []
    for group in dup_groups[:30]:
        winner = max(group, key=winner_key)
        losers = [row for row in group if int(row.get("id") or 0) != int(winner.get("id") or 0)]
        preview.append({
            "keep_id": int(winner.get("id") or 0),
            "keep": str(winner.get("content") or "")[:220],
            "remove_ids": [int(row.get("id") or 0) for row in losers],
        })

    repairs = sum(
        1 for row in rows
        if str(row.get("normalized_key") or "") != memory_normalized_key(str(row.get("content") or ""))
        or str(row.get("category") or "") != memory_category(str(row.get("content") or ""))
    )
    duplicates = sum(len(group) - 1 for group in dup_groups)
    result = {
        "scanned": len(rows), "duplicate_groups": len(dup_groups), "duplicates": duplicates,
        "repairs": repairs, "dry_run": bool(dry_run), "preview": preview,
    }
    if dry_run or (duplicates == 0 and repairs == 0):
        return result

    if int(chat_id or 0) > 0:
        save_memory_bundle(int(chat_id), "before Memory Optimizer")
    with db_connect() as db:
        for group in dup_groups:
            winner = max(group, key=winner_key)
            winner_id = int(winner["id"])
            losers = [row for row in group if int(row["id"]) != winner_id]
            combined_access = sum(max(0, int(row.get("access_count") or 0)) for row in group)
            combined_pinned = max(int(row.get("pinned") or 0) for row in group)
            combined_last_used = max(int(row.get("last_used_at") or 0) for row in group)
            combined_updated = max(int(row.get("updated_at") or 0) for row in group)
            content = str(winner.get("content") or "")
            db.execute(
                "UPDATE memories SET pinned=?,access_count=?,last_used_at=?,updated_at=?,category=?,normalized_key=? WHERE id=?",
                (combined_pinned, combined_access, combined_last_used, combined_updated,
                 memory_category(content), memory_normalized_key(content), winner_id),
            )
            if losers:
                ids = [int(row["id"]) for row in losers]
                placeholders = ",".join("?" for _ in ids)
                db.execute(f"DELETE FROM memories WHERE id IN ({placeholders})", ids)
        survivors = db.execute("SELECT id,content,category,normalized_key FROM memories").fetchall()
        for row in survivors:
            content = str(row["content"] or "")
            category = memory_category(content)
            key = memory_normalized_key(content)
            if str(row["category"] or "") != category or str(row["normalized_key"] or "") != key:
                db.execute("UPDATE memories SET category=?,normalized_key=? WHERE id=?", (category, key, int(row["id"])))
    if int(chat_id or 0) > 0:
        save_memory_bundle(int(chat_id), "Memory Optimizer completed")
    result["dry_run"] = False
    return result

__all__ = [
    "optimize_memories",

    "memory_terms",
    "memory_normalized_key",
    "memory_category",
    "memory_temperature",
    "memory_relevance_score",
    "retrieve_relevant_memories",
    "memory_is_near_duplicate",
    "memory_stats",
    "contains_sensitive_memory",
    "auto_extract_memories",
    "manual_context_to_memory",
    "list_memories",
    "add_memory",
    "edit_memory",
    "pin_memory",
    "set_memory_temperature",
    "delete_memory",
    "analyze_memory_bank",
    "optimize_memory_bank",
    "save_memory_bundle",
    "memory_export_zip",
]
