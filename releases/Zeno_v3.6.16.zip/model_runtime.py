#!/usr/bin/env python3
"""LM Studio model/runtime management for Zeno.

This module owns model loading, unload/reload decisions, compute placement,
hardware/runtime status, and lightweight model inventory caching. It deliberately
does not perform chat completions or prompt-based model routing.
"""

from __future__ import annotations

import copy
import ctypes
import json
import os
import platform as platform_module
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from config import (
    DEFAULT_COMPUTE_MODE,
    LM_STUDIO_URL,
    PREFERRED_DEEP_MODEL,
    PREFERRED_MODEL,
    SUPPORTED_COMPUTE_MODES,
)
from settings import compute_mode_setting, get_setting, model_mode_setting


_INVENTORY_TTL_SECONDS = 15.0
_STATUS_TTL_SECONDS = 2.0
_CAPABILITIES_TTL_SECONDS = 300.0
_HARDWARE_TELEMETRY_TTL_SECONDS = 5.0
_BACKEND_TIMEOUT_SECONDS = 4.0
_CLI_HELP_TIMEOUT_SECONDS = 10.0
_CLI_LOAD_TIMEOUT_SECONDS = 1800.0
_CLI_OTHER_TIMEOUT_SECONDS = 60.0
_MIN_CONTEXT_LENGTH = 1024
_MAX_CONTEXT_LENGTH = 262144
_DEFAULT_CONTEXT_LENGTH = 32768
_DEFAULT_PARALLEL = 1
_MAX_SUBPROCESS_TEXT = 64_000


class RuntimeState(str, Enum):
    UNAVAILABLE = "unavailable"
    DISCONNECTED = "disconnected"
    LOADING = "loading"
    LOADED = "loaded"
    RELOADING = "reloading"
    UNLOADING = "unloading"
    UNLOADED = "unloaded"
    ERROR = "error"


@dataclass(frozen=True)
class HardwareInfo:
    platform: str
    cpu_description: str
    logical_cpu_count: int | None
    total_system_ram: int | None
    available_system_ram: int | None
    gpu_name: str | None
    gpu_vram_total: int | None
    gpu_vram_available: int | None
    gpu_detection_source: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RuntimeCapabilities:
    native_rest_api: bool
    legacy_models_api: bool
    cli_available: bool
    cli_path: str | None
    cli_gpu_offload: bool
    cli_context_length: bool
    cli_parallel_support: bool
    cli_json_ls: bool
    cli_json_ps: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RequestedRuntimeConfig:
    model: str
    model_mode: str
    context_length: int
    parallel: int = _DEFAULT_PARALLEL
    compute_mode: str = DEFAULT_COMPUTE_MODE
    gpu_offload_requested: str = "auto"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EffectiveRuntimeConfig:
    model: str | None
    context_length: int | None
    parallel: int | None
    compute_mode: str | None
    gpu_offload: float | str | None
    instance_id: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ModelRuntimeStatus:
    state: RuntimeState
    backend_available: bool
    cli_available: bool
    requested_model: str
    effective_model: str | None
    model_mode: str
    requested_compute_mode: str
    effective_compute_mode: str | None
    requested_gpu_offload: str
    effective_gpu_offload: float | str | None
    context_length_requested: int
    context_length_effective: int | None
    parallel_requested: int
    parallel_effective: int | None
    cpu_fallback_active: bool
    fallback_reason: str | None
    loaded_instance_id: str | None
    last_error: str | None
    hardware_summary: HardwareInfo
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["state"] = self.state.value
        return payload


class ModelRuntimeManager:
    """Thread-safe runtime manager for one Zeno process.

    Construction is intentionally lightweight. No model is loaded, unloaded, or
    reconfigured until an explicit load/reload/unload method is called.
    """

    def __init__(self) -> None:
        self._mutation_lock = threading.RLock()
        self._cache_lock = threading.RLock()

        self._inventory_cache: list[dict[str, Any]] = []
        self._inventory_source = ""
        self._inventory_at = 0.0

        self._capabilities_cache: RuntimeCapabilities | None = None
        self._capabilities_at = 0.0

        self._hardware_identity: tuple[str, str, int | None] | None = None
        self._hardware_cache: HardwareInfo | None = None
        self._hardware_at = 0.0

        self._status_cache: ModelRuntimeStatus | None = None
        self._status_at = 0.0

        self._runtime_state = RuntimeState.UNAVAILABLE
        self._last_error: str | None = None

        self._managed_instance_id: str | None = None
        self._managed_model_key: str | None = None
        self._managed_requested: RequestedRuntimeConfig | None = None
        self._managed_effective: EffectiveRuntimeConfig | None = None
        self._owns_loaded_model = False

        self._cpu_fallback_active = False
        self._fallback_reason: str | None = None

        self._cli_path_checked = False
        self._cli_path: str | None = None

    # ------------------------------------------------------------------
    # Public status/configuration API
    # ------------------------------------------------------------------

    def requested_config(
        self,
        *,
        model_mode: str | None = None,
        context_length: int | None = None,
        compute_mode: str | None = None,
        gpu_offload_requested: str | None = None,
        parallel: int = _DEFAULT_PARALLEL,
    ) -> RequestedRuntimeConfig:
        mode = (model_mode or model_mode_setting()).strip().casefold()
        if mode not in {"fast", "balanced", "deep"}:
            raise ValueError("model_mode must be one of: fast, balanced, deep")

        fast_model = get_setting("fast_model", PREFERRED_MODEL).strip() or PREFERRED_MODEL
        deep_model = get_setting("deep_model", PREFERRED_DEEP_MODEL).strip() or PREFERRED_DEEP_MODEL
        model = deep_model if mode == "deep" else fast_model

        if context_length is None:
            raw_context = get_setting("context_window_tokens", str(_DEFAULT_CONTEXT_LENGTH)).strip()
            try:
                requested_context = int(raw_context)
            except ValueError as exc:
                raise ValueError("context_window_tokens must be an integer") from exc
        else:
            requested_context = int(context_length)

        if not (_MIN_CONTEXT_LENGTH <= requested_context <= _MAX_CONTEXT_LENGTH):
            raise ValueError(
                f"context length must be between {_MIN_CONTEXT_LENGTH} and {_MAX_CONTEXT_LENGTH}"
            )

        requested_parallel = int(parallel)
        if requested_parallel < 1 or requested_parallel > 64:
            raise ValueError("parallel must be between 1 and 64")

        compute = (compute_mode or compute_mode_setting()).strip().casefold()
        if compute not in set(SUPPORTED_COMPUTE_MODES):
            raise ValueError(
                "compute_mode must be one of: " + ", ".join(SUPPORTED_COMPUTE_MODES)
            )

        offload_text = (
            str(gpu_offload_requested)
            if gpu_offload_requested is not None
            else get_setting("gpu_offload_requested", "auto")
        ).strip()
        if not offload_text:
            offload_text = "auto"

        if compute == "partial_gpu":
            self._validate_partial_gpu_ratio(offload_text)

        return RequestedRuntimeConfig(
            model=model,
            model_mode=mode,
            context_length=requested_context,
            parallel=requested_parallel,
            compute_mode=compute,
            gpu_offload_requested=offload_text,
        )

    def available_models(self, refresh: bool = False) -> list[dict[str, Any]]:
        now = time.monotonic()
        with self._cache_lock:
            if (
                not refresh
                and self._inventory_cache
                and now - self._inventory_at < _INVENTORY_TTL_SECONDS
            ):
                return copy.deepcopy(self._inventory_cache)

        inventory, source = self._discover_models()

        with self._cache_lock:
            self._inventory_cache = inventory
            self._inventory_source = source
            self._inventory_at = time.monotonic()
        return copy.deepcopy(inventory)

    def capabilities(self, refresh: bool = False) -> RuntimeCapabilities:
        now = time.monotonic()
        with self._cache_lock:
            if (
                not refresh
                and self._capabilities_cache is not None
                and now - self._capabilities_at < _CAPABILITIES_TTL_SECONDS
            ):
                return self._capabilities_cache

        native_ok = self._native_models_endpoint_available()
        legacy_ok = False if native_ok else self._legacy_models_endpoint_available()
        cli_path = self._get_lms_executable()

        cli_gpu = False
        cli_context = False
        cli_parallel = False
        cli_json_ls = False
        cli_json_ps = False

        if cli_path:
            help_result = self._run_cli(
                ["load", "--help"],
                timeout=_CLI_HELP_TIMEOUT_SECONDS,
                check=False,
            )
            help_text = (help_result.stdout + "\n" + help_result.stderr).casefold()
            cli_gpu = "--gpu" in help_text
            cli_context = "--context-length" in help_text
            cli_parallel = "--parallel" in help_text

            ls_help = self._run_cli(
                ["ls", "--help"],
                timeout=_CLI_HELP_TIMEOUT_SECONDS,
                check=False,
            )
            cli_json_ls = "--json" in (ls_help.stdout + "\n" + ls_help.stderr).casefold()

            ps_help = self._run_cli(
                ["ps", "--help"],
                timeout=_CLI_HELP_TIMEOUT_SECONDS,
                check=False,
            )
            cli_json_ps = "--json" in (ps_help.stdout + "\n" + ps_help.stderr).casefold()

        result = RuntimeCapabilities(
            native_rest_api=native_ok,
            legacy_models_api=legacy_ok,
            cli_available=bool(cli_path),
            cli_path=cli_path,
            cli_gpu_offload=cli_gpu,
            cli_context_length=cli_context,
            cli_parallel_support=cli_parallel,
            cli_json_ls=cli_json_ls,
            cli_json_ps=cli_json_ps,
        )
        with self._cache_lock:
            self._capabilities_cache = result
            self._capabilities_at = time.monotonic()
        return result

    def hardware_info(self, refresh: bool = False) -> HardwareInfo:
        now = time.monotonic()
        with self._cache_lock:
            if (
                not refresh
                and self._hardware_cache is not None
                and now - self._hardware_at < _HARDWARE_TELEMETRY_TTL_SECONDS
            ):
                return self._hardware_cache

        if self._hardware_identity is None:
            system = platform_module.system() or sys_platform_name()
            cpu = platform_module.processor().strip() or os.environ.get("PROCESSOR_IDENTIFIER", "").strip()
            if not cpu:
                cpu = platform_module.machine().strip() or "Unknown CPU"
            self._hardware_identity = (system, cpu, os.cpu_count())

        system, cpu, logical_cpus = self._hardware_identity
        total_ram, available_ram = self._system_memory_bytes()
        gpu_name, gpu_total, gpu_free, gpu_source = self._nvidia_memory_info()

        result = HardwareInfo(
            platform=system,
            cpu_description=cpu,
            logical_cpu_count=logical_cpus,
            total_system_ram=total_ram,
            available_system_ram=available_ram,
            gpu_name=gpu_name,
            gpu_vram_total=gpu_total,
            gpu_vram_available=gpu_free,
            gpu_detection_source=gpu_source,
        )
        with self._cache_lock:
            self._hardware_cache = result
            self._hardware_at = time.monotonic()
        return result

    def status(self, refresh: bool = False) -> ModelRuntimeStatus:
        now = time.monotonic()
        with self._cache_lock:
            if (
                not refresh
                and self._status_cache is not None
                and now - self._status_at < _STATUS_TTL_SECONDS
            ):
                return copy.deepcopy(self._status_cache)

        status = self._build_status()
        with self._cache_lock:
            self._status_cache = status
            self._status_at = time.monotonic()
        return copy.deepcopy(status)

    def needs_reload(
        self,
        requested: RequestedRuntimeConfig | None = None,
        *,
        status: ModelRuntimeStatus | None = None,
    ) -> bool:
        requested = requested or self.requested_config()

        if self._managed_requested is not None and self._managed_effective is not None:
            return (
                self._managed_requested.model.casefold() != requested.model.casefold()
                or self._managed_requested.context_length != requested.context_length
                or self._managed_requested.parallel != requested.parallel
                or self._managed_requested.compute_mode != requested.compute_mode
                or self._managed_requested.gpu_offload_requested != requested.gpu_offload_requested
            )

        current = status or self.status(refresh=True)
        if not current.backend_available or not current.effective_model:
            return True
        if not self._model_names_equivalent(current.effective_model, requested.model):
            return True
        if (
            current.context_length_effective is not None
            and current.context_length_effective != requested.context_length
        ):
            return True
        if current.parallel_effective is not None and current.parallel_effective != requested.parallel:
            return True

        # For externally loaded models, an explicit GPU placement request cannot
        # be verified from the documented model-list fields, so a managed reload
        # would be needed to guarantee it. AUTO is allowed to keep the existing
        # compatible model because LM Studio owns the automatic placement choice.
        if requested.compute_mode != "auto":
            return True
        return False

    def load(
        self,
        requested: RequestedRuntimeConfig | None = None,
        *,
        allow_auto_cpu_fallback: bool = True,
    ) -> ModelRuntimeStatus:
        requested = requested or self.requested_config()
        self._validate_requested_against_inventory(requested)

        with self._mutation_lock:
            current = self.status(refresh=True)
            if not self.needs_reload(requested, status=current):
                return current

            self._runtime_state = RuntimeState.LOADING
            self._last_error = None
            self._cpu_fallback_active = False
            self._fallback_reason = None
            self._invalidate_status()

            try:
                effective = self._load_once(requested)
                self._record_managed_load(requested, effective)
                self._runtime_state = RuntimeState.LOADED
                return self.status(refresh=True)
            except Exception as first_exc:
                if requested.compute_mode == "auto" and allow_auto_cpu_fallback:
                    fallback_requested = RequestedRuntimeConfig(
                        model=requested.model,
                        model_mode=requested.model_mode,
                        context_length=requested.context_length,
                        parallel=requested.parallel,
                        compute_mode="cpu_only",
                        gpu_offload_requested=requested.gpu_offload_requested,
                    )
                    try:
                        effective = self._load_once(fallback_requested)
                        self._record_managed_load(requested, effective)
                        self._runtime_state = RuntimeState.LOADED
                        self._cpu_fallback_active = True
                        self._fallback_reason = f"Automatic GPU placement failed: {first_exc}"
                        self._last_error = None
                        return self.status(refresh=True)
                    except Exception as fallback_exc:
                        self._runtime_state = RuntimeState.ERROR
                        self._last_error = (
                            f"Automatic load failed: {first_exc}; "
                            f"CPU fallback also failed: {fallback_exc}"
                        )
                        self._invalidate_status()
                        return self.status(refresh=True)

                self._runtime_state = RuntimeState.ERROR
                self._last_error = str(first_exc)
                self._invalidate_status()
                return self.status(refresh=True)

    def reload(
        self,
        requested: RequestedRuntimeConfig | None = None,
        *,
        allow_auto_cpu_fallback: bool = True,
    ) -> ModelRuntimeStatus:
        requested = requested or self.requested_config()
        self._validate_requested_against_inventory(requested)

        with self._mutation_lock:
            current = self.status(refresh=True)
            if not self.needs_reload(requested, status=current):
                return current

            # Never silently unload a model instance we did not load/claim.
            if current.loaded_instance_id and current.loaded_instance_id != self._managed_instance_id:
                self._runtime_state = RuntimeState.ERROR
                self._last_error = (
                    "The currently loaded matching model instance is not owned by Zeno. "
                    "Refusing to unload it automatically."
                )
                self._invalidate_status()
                return self.status(refresh=True)

            self._runtime_state = RuntimeState.RELOADING
            self._last_error = None
            self._invalidate_status()

            if self._managed_instance_id or self._owns_loaded_model:
                unload_status = self.unload()
                if unload_status.state == RuntimeState.ERROR:
                    return unload_status

            return self.load(
                requested,
                allow_auto_cpu_fallback=allow_auto_cpu_fallback,
            )

    def load_cpu_fallback(
        self,
        requested: RequestedRuntimeConfig | None = None,
    ) -> ModelRuntimeStatus:
        original = requested or self.requested_config()
        cpu_request = RequestedRuntimeConfig(
            model=original.model,
            model_mode=original.model_mode,
            context_length=original.context_length,
            parallel=original.parallel,
            compute_mode="cpu_only",
            gpu_offload_requested=original.gpu_offload_requested,
        )
        with self._mutation_lock:
            try:
                effective = self._load_once(cpu_request)
                self._record_managed_load(original, effective)
                self._runtime_state = RuntimeState.LOADED
                self._cpu_fallback_active = True
                self._fallback_reason = "CPU fallback was explicitly requested."
                self._last_error = None
            except Exception as exc:
                self._runtime_state = RuntimeState.ERROR
                self._last_error = str(exc)
            self._invalidate_status()
            return self.status(refresh=True)

    def unload(
        self,
        instance_id: str | None = None,
        *,
        allow_unmanaged: bool = False,
    ) -> ModelRuntimeStatus:
        with self._mutation_lock:
            target_instance = instance_id or self._managed_instance_id
            if (
                target_instance
                and target_instance != self._managed_instance_id
                and not allow_unmanaged
            ):
                raise ValueError("Refusing to unload a model instance not owned by Zeno.")

            if not target_instance and not self._owns_loaded_model:
                self._runtime_state = RuntimeState.UNLOADED
                self._invalidate_status()
                return self.status(refresh=True)

            self._runtime_state = RuntimeState.UNLOADING
            self._last_error = None
            self._invalidate_status()

            try:
                caps = self.capabilities(refresh=True)
                if target_instance and caps.native_rest_api:
                    self._http_json(
                        "/api/v1/models/unload",
                        method="POST",
                        body={"instance_id": target_instance},
                        timeout=_BACKEND_TIMEOUT_SECONDS,
                    )
                elif self._owns_loaded_model and self._managed_model_key and caps.cli_available:
                    self._run_cli(
                        ["unload", self._managed_model_key],
                        timeout=_CLI_OTHER_TIMEOUT_SECONDS,
                        check=True,
                    )
                elif target_instance and allow_unmanaged and caps.cli_available:
                    self._run_cli(
                        ["unload", target_instance],
                        timeout=_CLI_OTHER_TIMEOUT_SECONDS,
                        check=True,
                    )
                else:
                    raise RuntimeError(
                        "No safe targeted unload mechanism is available for this model instance."
                    )
            except Exception as exc:
                self._runtime_state = RuntimeState.ERROR
                self._last_error = str(exc)
                self._invalidate_status()
                return self.status(refresh=True)

            self._managed_instance_id = None
            self._managed_model_key = None
            self._managed_requested = None
            self._managed_effective = None
            self._owns_loaded_model = False
            self._cpu_fallback_active = False
            self._fallback_reason = None
            self._runtime_state = RuntimeState.UNLOADED
            self._invalidate_inventory()
            self._invalidate_status()
            return self.status(refresh=True)

    def close(self, *, unload_owned: bool = False) -> None:
        if unload_owned and (self._managed_instance_id or self._owns_loaded_model):
            self.unload()

    shutdown = close

    # ------------------------------------------------------------------
    # Model discovery and backend helpers
    # ------------------------------------------------------------------

    def _discover_models(self) -> tuple[list[dict[str, Any]], str]:
        try:
            payload = self._http_json("/api/v1/models", timeout=_BACKEND_TIMEOUT_SECONDS)
            models = payload.get("models", []) if isinstance(payload, dict) else []
            if isinstance(models, list):
                return [self._normalize_native_model(item) for item in models if isinstance(item, dict)], "native"
        except Exception:
            pass

        try:
            payload = self._http_json("/v1/models", timeout=_BACKEND_TIMEOUT_SECONDS)
            data = payload.get("data", []) if isinstance(payload, dict) else []
            if isinstance(data, list):
                return [self._normalize_legacy_model(item) for item in data if isinstance(item, dict)], "legacy"
        except Exception:
            pass

        caps = self.capabilities_without_rest()
        if caps.cli_available and caps.cli_json_ls:
            try:
                result = self._run_cli(
                    ["ls", "--json"],
                    timeout=_CLI_OTHER_TIMEOUT_SECONDS,
                    check=True,
                )
                payload = json.loads(result.stdout)
                return self._normalize_cli_inventory(payload), "cli"
            except Exception:
                pass

        return [], "unavailable"

    @staticmethod
    def _normalize_native_model(item: dict[str, Any]) -> dict[str, Any]:
        loaded = item.get("loaded_instances")
        return {
            "key": str(item.get("key", "") or ""),
            "display_name": str(item.get("display_name", "") or ""),
            "type": str(item.get("type", "") or ""),
            "max_context_length": _safe_int(item.get("max_context_length")),
            "loaded_instances": copy.deepcopy(loaded) if isinstance(loaded, list) else [],
            "source": "native",
            "raw": copy.deepcopy(item),
        }

    @staticmethod
    def _normalize_legacy_model(item: dict[str, Any]) -> dict[str, Any]:
        return {
            "key": str(item.get("id", "") or ""),
            "display_name": str(item.get("id", "") or ""),
            "type": str(item.get("object", "") or ""),
            "max_context_length": None,
            "loaded_instances": None,
            "source": "legacy",
            "raw": copy.deepcopy(item),
        }

    @staticmethod
    def _normalize_cli_inventory(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, dict):
            candidates = (
                payload.get("models")
                or payload.get("data")
                or payload.get("items")
                or []
            )
        elif isinstance(payload, list):
            candidates = payload
        else:
            candidates = []

        normalized: list[dict[str, Any]] = []
        for item in candidates:
            if not isinstance(item, dict):
                continue
            key = (
                item.get("key")
                or item.get("modelKey")
                or item.get("model_key")
                or item.get("path")
                or item.get("id")
                or ""
            )
            if not key:
                continue
            normalized.append({
                "key": str(key),
                "display_name": str(item.get("displayName") or item.get("name") or key),
                "type": str(item.get("type") or ""),
                "max_context_length": _safe_int(
                    item.get("maxContextLength") or item.get("max_context_length")
                ),
                "loaded_instances": None,
                "source": "cli",
                "raw": copy.deepcopy(item),
            })
        return normalized

    def _native_models_endpoint_available(self) -> bool:
        try:
            payload = self._http_json("/api/v1/models", timeout=_BACKEND_TIMEOUT_SECONDS)
            return isinstance(payload, dict) and isinstance(payload.get("models"), list)
        except Exception:
            return False

    def _legacy_models_endpoint_available(self) -> bool:
        try:
            payload = self._http_json("/v1/models", timeout=_BACKEND_TIMEOUT_SECONDS)
            return isinstance(payload, dict) and isinstance(payload.get("data"), list)
        except Exception:
            return False

    def capabilities_without_rest(self) -> RuntimeCapabilities:
        """Detect CLI capabilities without probing the HTTP backend.

        This helper avoids recursion when model discovery itself falls back to CLI.
        """
        cli_path = self._get_lms_executable()
        if not cli_path:
            return RuntimeCapabilities(
                native_rest_api=False,
                legacy_models_api=False,
                cli_available=False,
                cli_path=None,
                cli_gpu_offload=False,
                cli_context_length=False,
                cli_parallel_support=False,
                cli_json_ls=False,
                cli_json_ps=False,
            )

        help_result = self._run_cli(
            ["load", "--help"],
            timeout=_CLI_HELP_TIMEOUT_SECONDS,
            check=False,
        )
        help_text = (help_result.stdout + "\n" + help_result.stderr).casefold()

        ls_help = self._run_cli(["ls", "--help"], timeout=_CLI_HELP_TIMEOUT_SECONDS, check=False)
        ps_help = self._run_cli(["ps", "--help"], timeout=_CLI_HELP_TIMEOUT_SECONDS, check=False)

        return RuntimeCapabilities(
            native_rest_api=False,
            legacy_models_api=False,
            cli_available=True,
            cli_path=cli_path,
            cli_gpu_offload="--gpu" in help_text,
            cli_context_length="--context-length" in help_text,
            cli_parallel_support="--parallel" in help_text,
            cli_json_ls="--json" in (ls_help.stdout + "\n" + ls_help.stderr).casefold(),
            cli_json_ps="--json" in (ps_help.stdout + "\n" + ps_help.stderr).casefold(),
        )

    def resolve_model_key(
        self,
        configured_model: str,
        *,
        inventory: list[dict[str, Any]] | None = None,
    ) -> str:
        configured = str(configured_model).strip()
        if not configured:
            raise ValueError("Configured model id is empty.")

        records = inventory if inventory is not None else self.available_models()
        if not records:
            return configured

        keys = [str(item.get("key", "") or "") for item in records]
        exact = [key for key in keys if key == configured]
        if exact:
            return exact[0]

        folded = [key for key in keys if key.casefold() == configured.casefold()]
        if len(folded) == 1:
            return folded[0]
        if len(folded) > 1:
            raise ValueError(f"Model id is ambiguous: {configured}")

        configured_base = _model_basename(configured)
        basename_matches = [key for key in keys if _model_basename(key) == configured_base]
        if len(basename_matches) == 1:
            return basename_matches[0]
        if len(basename_matches) > 1:
            raise ValueError(
                f"Model id {configured!r} matches multiple LM Studio models. "
                "Use an exact model key."
            )

        raise ValueError(f"Configured model was not found in LM Studio: {configured}")

    def _validate_requested_against_inventory(self, requested: RequestedRuntimeConfig) -> None:
        inventory = self.available_models(refresh=True)
        if not inventory:
            return
        resolved = self.resolve_model_key(requested.model, inventory=inventory)
        record = next(
            (item for item in inventory if str(item.get("key", "")) == resolved),
            None,
        )
        if record:
            max_context = _safe_int(record.get("max_context_length"))
            if max_context is not None and requested.context_length > max_context:
                raise ValueError(
                    f"Requested context length {requested.context_length:,} exceeds "
                    f"the model's reported maximum of {max_context:,}."
                )

    # ------------------------------------------------------------------
    # Load / unload internals
    # ------------------------------------------------------------------

    def _load_once(self, requested: RequestedRuntimeConfig) -> EffectiveRuntimeConfig:
        inventory_before = self.available_models(refresh=True)
        resolved_model = self.resolve_model_key(requested.model, inventory=inventory_before)
        before_ids = self._loaded_instance_ids(inventory_before, resolved_model)
        caps = self.capabilities(refresh=True)

        if caps.cli_available:
            args = ["load", resolved_model]

            if not caps.cli_context_length:
                raise RuntimeError(
                    "Installed lms CLI does not advertise --context-length, "
                    "so Zeno cannot guarantee the requested runtime context."
                )
            args.extend(["--context-length", str(requested.context_length)])

            if caps.cli_parallel_support:
                args.extend(["--parallel", str(requested.parallel)])
            elif requested.parallel != _DEFAULT_PARALLEL:
                raise RuntimeError(
                    "Installed lms CLI does not support --parallel, so the requested "
                    "parallel value cannot be applied."
                )

            gpu_value = self._cli_gpu_value(requested)
            if gpu_value is not None:
                if not caps.cli_gpu_offload:
                    raise RuntimeError(
                        "Installed lms CLI does not advertise --gpu, so the requested "
                        "compute mode cannot be applied."
                    )
                args.extend(["--gpu", gpu_value])

            self._run_cli(
                args,
                timeout=_CLI_LOAD_TIMEOUT_SECONDS,
                check=True,
            )

            self._invalidate_inventory()
            after = self.available_models(refresh=True)
            after_ids = self._loaded_instance_ids(after, resolved_model)
            new_ids = [instance_id for instance_id in after_ids if instance_id not in before_ids]
            instance_id = new_ids[0] if len(new_ids) == 1 else None
            owns_model = not before_ids
            self._owns_loaded_model = owns_model

            effective_context, effective_parallel = self._loaded_config_values(
                after, resolved_model, instance_id
            )
            return EffectiveRuntimeConfig(
                model=resolved_model,
                context_length=effective_context or requested.context_length,
                parallel=effective_parallel or requested.parallel,
                compute_mode=requested.compute_mode,
                gpu_offload=None,
                instance_id=instance_id,
            )

        # REST can safely serve AUTO loads, but the documented v1 load schema does
        # not expose the CLI's general GPU offload ratio control or parallel flag.
        if requested.compute_mode != "auto":
            raise RuntimeError(
                "LM Studio CLI is required for max_gpu, partial_gpu, and cpu_only modes."
            )
        if requested.parallel != _DEFAULT_PARALLEL:
            raise RuntimeError(
                "LM Studio CLI is required to set a non-default parallel value."
            )

        body = {
            "model": resolved_model,
            "context_length": requested.context_length,
            "echo_load_config": True,
        }
        response = self._http_json(
            "/api/v1/models/load",
            method="POST",
            body=body,
            timeout=_CLI_LOAD_TIMEOUT_SECONDS,
        )
        instance_id = str(response.get("instance_id", "") or "") or None
        load_config = response.get("load_config") if isinstance(response, dict) else {}
        if not isinstance(load_config, dict):
            load_config = {}

        self._owns_loaded_model = bool(instance_id)
        self._invalidate_inventory()

        return EffectiveRuntimeConfig(
            model=resolved_model,
            context_length=_safe_int(load_config.get("context_length")) or requested.context_length,
            parallel=None,
            compute_mode="auto",
            gpu_offload=None,
            instance_id=instance_id,
        )

    @staticmethod
    def _validate_partial_gpu_ratio(value: str) -> float:
        try:
            ratio = float(str(value).strip())
        except ValueError as exc:
            raise ValueError(
                "partial_gpu requires gpu_offload_requested to be a numeric ratio from 0.0 to 1.0"
            ) from exc
        if not 0.0 <= ratio <= 1.0:
            raise ValueError(
                "partial_gpu requires gpu_offload_requested to be between 0.0 and 1.0"
            )
        return ratio

    def _cli_gpu_value(self, requested: RequestedRuntimeConfig) -> str | None:
        if requested.compute_mode == "auto":
            return None
        if requested.compute_mode == "max_gpu":
            return "max"
        if requested.compute_mode == "cpu_only":
            return "off"
        if requested.compute_mode == "partial_gpu":
            ratio = self._validate_partial_gpu_ratio(requested.gpu_offload_requested)
            return format(ratio, ".6g")
        raise ValueError(f"Unsupported compute mode: {requested.compute_mode}")

    def _record_managed_load(
        self,
        requested: RequestedRuntimeConfig,
        effective: EffectiveRuntimeConfig,
    ) -> None:
        self._managed_requested = requested
        self._managed_effective = effective
        self._managed_model_key = effective.model
        self._managed_instance_id = effective.instance_id
        self._invalidate_inventory()
        self._invalidate_status()

    # ------------------------------------------------------------------
    # Status assembly
    # ------------------------------------------------------------------

    def _build_status(self) -> ModelRuntimeStatus:
        try:
            requested = self.requested_config()
        except Exception as exc:
            hardware = self.hardware_info()
            return ModelRuntimeStatus(
                state=RuntimeState.ERROR,
                backend_available=False,
                cli_available=bool(self._get_lms_executable()),
                requested_model="",
                effective_model=None,
                model_mode="balanced",
                requested_compute_mode=DEFAULT_COMPUTE_MODE,
                effective_compute_mode=None,
                requested_gpu_offload="auto",
                effective_gpu_offload=None,
                context_length_requested=_DEFAULT_CONTEXT_LENGTH,
                context_length_effective=None,
                parallel_requested=_DEFAULT_PARALLEL,
                parallel_effective=None,
                cpu_fallback_active=self._cpu_fallback_active,
                fallback_reason=self._fallback_reason,
                loaded_instance_id=self._managed_instance_id,
                last_error=str(exc),
                hardware_summary=hardware,
            )

        inventory = self.available_models(refresh=True)
        source = self._inventory_source
        backend_available = source in {"native", "legacy"}
        cli_available = bool(self._get_lms_executable())

        resolved_requested = requested.model
        try:
            if inventory:
                resolved_requested = self.resolve_model_key(requested.model, inventory=inventory)
        except Exception:
            pass

        instance = self._find_loaded_instance(
            inventory,
            self._managed_instance_id,
            self._managed_model_key or resolved_requested,
        )

        effective_model = None
        effective_context = None
        effective_parallel = None
        loaded_instance_id = self._managed_instance_id

        if instance is not None:
            effective_model = str(instance.get("_model_key", "") or "") or None
            loaded_instance_id = str(instance.get("id", "") or "") or loaded_instance_id
            config = instance.get("config")
            if isinstance(config, dict):
                effective_context = _safe_int(config.get("context_length"))
                effective_parallel = _safe_int(config.get("parallel"))
        elif self._managed_effective is not None:
            effective_model = self._managed_effective.model
            effective_context = self._managed_effective.context_length
            effective_parallel = self._managed_effective.parallel

        if self._managed_effective is not None:
            effective_compute = self._managed_effective.compute_mode
        else:
            effective_compute = None

        if self._runtime_state in {
            RuntimeState.LOADING,
            RuntimeState.RELOADING,
            RuntimeState.UNLOADING,
            RuntimeState.ERROR,
        }:
            state = self._runtime_state
        elif effective_model:
            state = RuntimeState.LOADED
        elif backend_available:
            state = RuntimeState.UNLOADED
        elif cli_available:
            state = RuntimeState.DISCONNECTED
        else:
            state = RuntimeState.UNAVAILABLE

        return ModelRuntimeStatus(
            state=state,
            backend_available=backend_available,
            cli_available=cli_available,
            requested_model=requested.model,
            effective_model=effective_model,
            model_mode=requested.model_mode,
            requested_compute_mode=requested.compute_mode,
            effective_compute_mode=effective_compute,
            requested_gpu_offload=requested.gpu_offload_requested,
            # The documented model-list fields do not expose the general CLI GPU
            # offload ratio, so do not fabricate an "effective" value.
            effective_gpu_offload=None,
            context_length_requested=requested.context_length,
            context_length_effective=effective_context,
            parallel_requested=requested.parallel,
            parallel_effective=effective_parallel,
            cpu_fallback_active=self._cpu_fallback_active,
            fallback_reason=self._fallback_reason,
            loaded_instance_id=loaded_instance_id,
            last_error=self._last_error,
            hardware_summary=self.hardware_info(),
        )

    @staticmethod
    def _loaded_instance_ids(
        inventory: list[dict[str, Any]],
        model_key: str,
    ) -> list[str]:
        ids: list[str] = []
        for record in inventory:
            if not ModelRuntimeManager._model_names_equivalent(
                str(record.get("key", "")), model_key
            ):
                continue
            loaded = record.get("loaded_instances")
            if isinstance(loaded, list):
                for item in loaded:
                    if isinstance(item, dict) and item.get("id"):
                        ids.append(str(item["id"]))
        return ids

    @staticmethod
    def _loaded_config_values(
        inventory: list[dict[str, Any]],
        model_key: str,
        instance_id: str | None,
    ) -> tuple[int | None, int | None]:
        for record in inventory:
            if not ModelRuntimeManager._model_names_equivalent(
                str(record.get("key", "")), model_key
            ):
                continue
            loaded = record.get("loaded_instances")
            if not isinstance(loaded, list):
                continue
            for item in loaded:
                if not isinstance(item, dict):
                    continue
                if instance_id and str(item.get("id", "")) != instance_id:
                    continue
                config = item.get("config")
                if isinstance(config, dict):
                    return (
                        _safe_int(config.get("context_length")),
                        _safe_int(config.get("parallel")),
                    )
        return None, None

    @staticmethod
    def _find_loaded_instance(
        inventory: list[dict[str, Any]],
        instance_id: str | None,
        model_key: str | None,
    ) -> dict[str, Any] | None:
        candidates: list[dict[str, Any]] = []
        for record in inventory:
            loaded = record.get("loaded_instances")
            if not isinstance(loaded, list):
                continue
            for item in loaded:
                if not isinstance(item, dict):
                    continue
                candidate = copy.deepcopy(item)
                candidate["_model_key"] = str(record.get("key", ""))
                candidates.append(candidate)

        if instance_id:
            for item in candidates:
                if str(item.get("id", "")) == instance_id:
                    return item

        if model_key:
            matches = [
                item
                for item in candidates
                if ModelRuntimeManager._model_names_equivalent(
                    str(item.get("_model_key", "")), model_key
                )
            ]
            if len(matches) == 1:
                return matches[0]
        return None

    @staticmethod
    def _model_names_equivalent(left: str, right: str) -> bool:
        if left.casefold() == right.casefold():
            return True
        return _model_basename(left) == _model_basename(right)

    # ------------------------------------------------------------------
    # HTTP and subprocess helpers
    # ------------------------------------------------------------------

    def _http_json(
        self,
        path: str,
        *,
        method: str = "GET",
        body: dict[str, Any] | None = None,
        timeout: float = _BACKEND_TIMEOUT_SECONDS,
    ) -> dict[str, Any]:
        base = urllib.parse.urlsplit(LM_STUDIO_URL)
        if base.scheme not in {"http", "https"}:
            raise RuntimeError("LM_STUDIO_URL must use http or https.")
        if not base.hostname:
            raise RuntimeError("LM_STUDIO_URL has no hostname.")

        # Only the configured backend is ever targeted.
        url = LM_STUDIO_URL.rstrip("/") + "/" + path.lstrip("/")
        data = None
        headers = {"Accept": "application/json"}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = urllib.request.Request(
            url,
            data=data,
            method=method.upper(),
            headers=headers,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read(4_000_000)
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read(8_000).decode("utf-8", errors="replace")
            except Exception:
                pass
            raise RuntimeError(
                f"LM Studio returned HTTP {exc.code}: {detail or exc.reason}"
            ) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"LM Studio is unreachable: {exc.reason}") from exc

        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("LM Studio returned invalid JSON.") from exc
        if not isinstance(payload, dict):
            raise RuntimeError("LM Studio returned an unexpected JSON payload.")
        return payload

    def _get_lms_executable(self) -> str | None:
        if self._cli_path_checked:
            return self._cli_path
        with self._cache_lock:
            if not self._cli_path_checked:
                self._cli_path = (
                    shutil.which("lms")
                    or shutil.which("lms.exe")
                    or shutil.which("lms.cmd")
                )
                self._cli_path_checked = True
        return self._cli_path

    def _run_cli(
        self,
        arguments: list[str],
        *,
        timeout: float,
        check: bool,
    ) -> subprocess.CompletedProcess[str]:
        executable = self._get_lms_executable()
        if not executable:
            raise RuntimeError("LM Studio CLI (lms) is not available on PATH.")

        command = [executable, *[str(arg) for arg in arguments]]
        try:
            result = subprocess.run(
                command,
                shell=False,
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"LM Studio CLI timed out after {timeout:g} seconds.") from exc
        except OSError as exc:
            raise RuntimeError(f"Could not start LM Studio CLI: {exc}") from exc

        # Bound retained output before it is surfaced in an exception.
        result.stdout = (result.stdout or "")[-_MAX_SUBPROCESS_TEXT:]
        result.stderr = (result.stderr or "")[-_MAX_SUBPROCESS_TEXT:]

        if check and result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or f"exit code {result.returncode}"
            raise RuntimeError(f"LM Studio CLI failed: {detail}")
        return result

    # ------------------------------------------------------------------
    # Hardware helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _system_memory_bytes() -> tuple[int | None, int | None]:
        system = platform_module.system().casefold()

        if system == "windows":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            try:
                status = MEMORYSTATUSEX()
                status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return int(status.ullTotalPhys), int(status.ullAvailPhys)
            except Exception:
                return None, None

        if system == "linux":
            try:
                values: dict[str, int] = {}
                with open("/proc/meminfo", "r", encoding="utf-8") as handle:
                    for line in handle:
                        key, raw = line.split(":", 1)
                        match = re.search(r"(\d+)", raw)
                        if match:
                            values[key] = int(match.group(1)) * 1024
                total = values.get("MemTotal")
                available = values.get("MemAvailable") or values.get("MemFree")
                return total, available
            except (OSError, ValueError):
                return None, None

        if system == "darwin":
            try:
                total_result = subprocess.run(
                    ["sysctl", "-n", "hw.memsize"],
                    shell=False,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=3,
                    check=False,
                )
                total = int(total_result.stdout.strip()) if total_result.returncode == 0 else None
                return total, None
            except (OSError, ValueError, subprocess.TimeoutExpired):
                return None, None

        return None, None

    def _nvidia_memory_info(
        self,
    ) -> tuple[str | None, int | None, int | None, str]:
        executable = shutil.which("nvidia-smi")
        if not executable:
            return None, None, None, "unavailable"

        try:
            result = subprocess.run(
                [
                    executable,
                    "--query-gpu=name,memory.total,memory.free",
                    "--format=csv,noheader,nounits",
                ],
                shell=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=4,
                check=False,
            )
            if result.returncode != 0:
                return None, None, None, "nvidia-smi-error"

            names: list[str] = []
            total_mib = 0
            free_mib = 0
            rows = 0
            for line in result.stdout.splitlines():
                parts = [part.strip() for part in line.split(",")]
                if len(parts) < 3:
                    continue
                try:
                    total_value = float(parts[-2])
                    free_value = float(parts[-1])
                except ValueError:
                    continue
                names.append(",".join(parts[:-2]).strip() or "NVIDIA GPU")
                total_mib += int(total_value)
                free_mib += int(free_value)
                rows += 1

            if not rows:
                return None, None, None, "nvidia-smi-no-data"

            return (
                " + ".join(names),
                total_mib * 1024 * 1024,
                free_mib * 1024 * 1024,
                "nvidia-smi",
            )
        except (OSError, subprocess.TimeoutExpired):
            return None, None, None, "nvidia-smi-error"

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _invalidate_inventory(self) -> None:
        with self._cache_lock:
            self._inventory_cache = []
            self._inventory_source = ""
            self._inventory_at = 0.0

    def _invalidate_status(self) -> None:
        with self._cache_lock:
            self._status_cache = None
            self._status_at = 0.0


def _safe_int(value: Any) -> int | None:
    try:
        if value is None or isinstance(value, bool):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _model_basename(value: str) -> str:
    text = str(value or "").replace("\\", "/").rstrip("/")
    return text.rsplit("/", 1)[-1].casefold()


def sys_platform_name() -> str:
    return os.name or "unknown"


__all__ = [
    "RuntimeState",
    "HardwareInfo",
    "RuntimeCapabilities",
    "RequestedRuntimeConfig",
    "EffectiveRuntimeConfig",
    "ModelRuntimeStatus",
    "ModelRuntimeManager",
]
