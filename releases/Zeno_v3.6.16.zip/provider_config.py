#!/usr/bin/env python3
"""Private API-provider configuration for Zeno.

Provider keys stay in ``zeno_data/private/api_providers.json`` and are never
returned to the browser.  The provider surface is OpenAI-compatible so new
routers can be added without changing Zeno's chat pipeline.
"""
from __future__ import annotations

import json
import os
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from config import PRIVATE_DIR

API_PROVIDERS_PATH = PRIVATE_DIR / "api_providers.json"
_LOCK = threading.RLock()

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "local": {"name": "LM Studio (local)", "base_url": "http://127.0.0.1:1234", "model": ""},
    "openrouter": {"name": "OpenRouter", "base_url": "https://openrouter.ai/api/v1", "model": ""},
    "quartzrouter": {"name": "QuartzRouter", "base_url": "https://api.quartzrouter.com/v1", "model": ""},
    "custom": {"name": "Custom OpenAI-compatible", "base_url": "", "model": ""},
}


def _atomic_write(value: dict[str, Any]) -> None:
    API_PROVIDERS_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = API_PROVIDERS_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temp, API_PROVIDERS_PATH)
    try:
        os.chmod(API_PROVIDERS_PATH, 0o600)
    except OSError:
        pass


def _clean_url(value: str, *, required: bool = False) -> str:
    url = str(value or "").strip().rstrip("/")
    if not url:
        if required:
            raise ValueError("An API base URL is required for this provider.")
        return ""
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("API base URL must be a valid http:// or https:// URL.")
    return url


def _normalize(raw: dict[str, Any], provider_id: str) -> dict[str, Any]:
    defaults = PROVIDER_DEFAULTS.get(provider_id, PROVIDER_DEFAULTS["custom"])
    item = {
        "id": provider_id,
        "name": str(raw.get("name") or defaults["name"]).strip()[:80],
        "base_url": _clean_url(str(raw.get("base_url") or defaults["base_url"])),
        "model": str(raw.get("model") or defaults["model"]).strip()[:240],
        "api_key": str(raw.get("api_key") or "").strip()[:2000],
    }
    return item


def _load() -> dict[str, Any]:
    result: dict[str, Any] = {"active": "local", "providers": {}}
    try:
        loaded = json.loads(API_PROVIDERS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        loaded = {}
    if isinstance(loaded, dict):
        active = str(loaded.get("active") or "local").casefold()
        result["active"] = active if active in PROVIDER_DEFAULTS else "local"
        providers = loaded.get("providers")
        if isinstance(providers, dict):
            result["providers"] = {
                str(key).casefold(): _normalize(value, str(key).casefold())
                for key, value in providers.items()
                if isinstance(value, dict)
            }
    for provider_id, defaults in PROVIDER_DEFAULTS.items():
        result["providers"].setdefault(provider_id, _normalize({}, provider_id))
    return result


def active_config() -> dict[str, Any]:
    with _LOCK:
        loaded = _load()
        provider_id = str(loaded["active"])
        return dict(loaded["providers"].get(provider_id) or _normalize({}, provider_id))


def provider_config(provider_id: str) -> dict[str, Any]:
    wanted = str(provider_id or "local").casefold().strip()
    with _LOCK:
        loaded = _load()
        return dict(loaded["providers"].get(wanted) or _normalize({}, wanted))


def save_provider(values: dict[str, Any]) -> dict[str, Any]:
    provider_id = str(values.get("id") or values.get("provider") or "local").casefold().strip()
    if provider_id not in PROVIDER_DEFAULTS:
        raise ValueError("Unknown API provider. Choose Local, OpenRouter, QuartzRouter, or Custom.")
    with _LOCK:
        loaded = _load()
        existing = dict(loaded["providers"].get(provider_id) or _normalize({}, provider_id))
        merged = dict(existing)
        merged.update({key: value for key, value in values.items() if key in {"name", "base_url", "model", "api_key"}})
        if "api_key" not in values or not str(values.get("api_key") or "").strip():
            merged["api_key"] = existing.get("api_key", "")
        merged = _normalize(merged, provider_id)
        if provider_id != "local":
            merged["base_url"] = _clean_url(merged["base_url"], required=True)
            if not merged["api_key"]:
                raise ValueError("An API key is required before enabling a remote provider.")
        loaded["providers"][provider_id] = merged
        loaded["active"] = provider_id if bool(values.get("active", True)) else loaded["active"]
        _atomic_write(loaded)
        return public_provider_state(loaded)


def public_provider_state(loaded: dict[str, Any] | None = None) -> dict[str, Any]:
    loaded = loaded or _load()
    providers: list[dict[str, Any]] = []
    for provider_id, defaults in PROVIDER_DEFAULTS.items():
        item = dict(loaded.get("providers", {}).get(provider_id) or _normalize({}, provider_id))
        key = str(item.pop("api_key", "") or "")
        item["id"] = provider_id
        item["name"] = str(item.get("name") or defaults["name"])
        item["has_key"] = bool(key)
        item["key_hint"] = ("••••" + key[-4:]) if key else ""
        providers.append(item)
    return {"ok": True, "active": str(loaded.get("active") or "local"), "providers": providers}


def api_provider_state() -> dict[str, Any]:
    with _LOCK:
        return public_provider_state(_load())


def test_provider(provider_id: str | None = None) -> dict[str, Any]:
    config = active_config() if not provider_id else provider_config(provider_id)
    wanted = str(config.get("id") or provider_id or "local")
    if wanted == "local":
        return {"ok": True, "provider": wanted, "detail": "Local provider selected; use the model refresh button to check LM Studio."}
    base_url = _clean_url(str(config.get("base_url") or ""), required=True)
    key = str(config.get("api_key") or "")
    if not key:
        raise ValueError("No API key is saved for this provider.")
    request = urllib.request.Request(
        base_url + "/models",
        headers={"Accept": "application/json", "Authorization": "Bearer " + key},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read(2_000_000).decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        detail = exc.read(1200).decode("utf-8", errors="replace")
        raise RuntimeError(f"{config.get('name', wanted)} returned HTTP {exc.code}: {detail or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach {config.get('name', wanted)}: {exc.reason}") from exc
    models = payload.get("data", []) if isinstance(payload, dict) else []
    return {"ok": True, "provider": wanted, "detail": f"Connected · {len(models) if isinstance(models, list) else 0} models visible."}


__all__ = ["PROVIDER_DEFAULTS", "active_config", "provider_config", "save_provider", "api_provider_state", "test_provider"]
