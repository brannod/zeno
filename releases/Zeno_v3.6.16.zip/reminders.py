#!/usr/bin/env python3
"""Persistent local reminders for Zeno.

Reminders are intentionally model-free and stored outside the main SQLite schema,
so adding the feature does not require a database migration.
"""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
from typing import Any

from config import BASE_DIR

REMINDERS_PATH = Path(BASE_DIR) / "zeno_data" / "reminders.json"
_LOCK = threading.RLock()


def _now() -> int:
    return int(time.time())


def _load() -> list[dict[str, Any]]:
    try:
        value = json.loads(REMINDERS_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, UnicodeError, json.JSONDecodeError):
        return []
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _save(rows: list[dict[str, Any]]) -> None:
    REMINDERS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = REMINDERS_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, REMINDERS_PATH)


def _clock_time(text: str) -> tuple[int, int] | None:
    value = re.sub(r"\s+", " ", str(text or "")).strip().casefold().replace(".", "")
    match = re.fullmatch(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", value)
    if not match:
        return None
    hour = int(match.group(1))
    minute = int(match.group(2) or 0)
    suffix = match.group(3)
    if minute > 59:
        return None
    if suffix:
        if hour < 1 or hour > 12:
            return None
        if suffix == "pm" and hour != 12:
            hour += 12
        elif suffix == "am" and hour == 12:
            hour = 0
    elif hour > 23:
        return None
    return hour, minute


def parse_reminder_when(value: str, *, now_ts: int | None = None) -> int:
    """Parse a compact human time using the RDP/system local timezone."""
    raw = re.sub(r"\s+", " ", str(value or "")).strip()
    folded = raw.casefold()
    if not raw:
        raise ValueError("Enter when Zeno should remind you, such as `30m` or `tomorrow at 3pm`.")
    base_ts = int(now_ts or _now())
    base = dt.datetime.fromtimestamp(base_ts).astimezone()

    compact = re.fullmatch(r"(\d{1,6})\s*([smhdw])", folded)
    if compact:
        amount = int(compact.group(1))
        seconds = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[compact.group(2)]
        due = base_ts + amount * seconds
        if due <= base_ts:
            raise ValueError("Reminder time must be in the future.")
        return due

    relative = re.fullmatch(
        r"(?:in\s+)?(\d{1,6})\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?)",
        folded,
    )
    if relative:
        amount = int(relative.group(1))
        unit = relative.group(2)
        if unit.startswith(("second", "sec")):
            seconds = 1
        elif unit.startswith(("minute", "min")):
            seconds = 60
        elif unit.startswith(("hour", "hr")):
            seconds = 3600
        elif unit.startswith("day"):
            seconds = 86400
        else:
            seconds = 604800
        due = base_ts + amount * seconds
        if due <= base_ts:
            raise ValueError("Reminder time must be in the future.")
        return due

    day_match = re.fullmatch(r"(today|tomorrow)(?:\s+at)?\s+(.+)", folded)
    if day_match:
        clock = _clock_time(day_match.group(2))
        if not clock:
            raise ValueError("Use a time like `3pm` or `15:30`.")
        target_date = base.date() + dt.timedelta(days=1 if day_match.group(1) == "tomorrow" else 0)
        target = dt.datetime.combine(target_date, dt.time(clock[0], clock[1]), tzinfo=base.tzinfo)
        if target.timestamp() <= base_ts:
            raise ValueError("That time has already passed.")
        return int(target.timestamp())

    at_match = re.fullmatch(r"(?:at\s+)?(.+)", folded)
    clock = _clock_time(at_match.group(1)) if at_match else None
    if clock:
        target = dt.datetime.combine(base.date(), dt.time(clock[0], clock[1]), tzinfo=base.tzinfo)
        if target.timestamp() <= base_ts:
            target += dt.timedelta(days=1)
        return int(target.timestamp())

    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %I:%M%p", "%Y-%m-%d %I%p"):
        try:
            naive = dt.datetime.strptime(raw.replace(" ", " "), fmt)
            target = naive.replace(tzinfo=base.tzinfo)
            if target.timestamp() <= base_ts:
                raise ValueError("Reminder time must be in the future.")
            return int(target.timestamp())
        except ValueError:
            continue
    raise ValueError("I couldn't understand that reminder time. Try `30m`, `2 hours`, `tomorrow at 3pm`, or `2026-09-01 15:30`.")


def create_reminder(
    chat_id: int,
    channel_id: int,
    owner_id: int,
    when: str,
    text: str,
    *,
    source: str = "discord",
) -> dict[str, Any]:
    message = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(message) < 1 or len(message) > 1500:
        raise ValueError("Reminder text must be between 1 and 1,500 characters.")
    due_at = parse_reminder_when(when)
    row = {
        "id": uuid.uuid4().hex[:10],
        "chat_id": int(chat_id),
        "channel_id": int(channel_id),
        "owner_id": int(owner_id or 0),
        "text": message,
        "due_at": due_at,
        "created_at": _now(),
        "delivered_at": 0,
        "cancelled_at": 0,
        "source": str(source)[:40],
    }
    with _LOCK:
        rows = _load()
        rows.append(row)
        _save(rows[-2000:])
    return dict(row)


def create_reminder_from_text(chat_id: int, channel_id: int, owner_id: int, text: str) -> dict[str, Any]:
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    match = re.match(r"(?i)^remind\s+me\s+(.+?)\s+to\s+(.+)$", value)
    if not match:
        raise ValueError("Try `remind me in 30 minutes to check the job`.")
    return create_reminder(chat_id, channel_id, owner_id, match.group(1), match.group(2), source="discord-natural")


def list_reminders(*, chat_id: int | None = None, owner_id: int | None = None, include_done: bool = False) -> list[dict[str, Any]]:
    with _LOCK:
        rows = _load()
    result = []
    for row in rows:
        if chat_id is not None and int(row.get("chat_id") or 0) != int(chat_id):
            continue
        if owner_id is not None and int(row.get("owner_id") or 0) != int(owner_id):
            continue
        if not include_done and (int(row.get("delivered_at") or 0) or int(row.get("cancelled_at") or 0)):
            continue
        result.append(dict(row))
    result.sort(key=lambda item: (int(item.get("due_at") or 0), str(item.get("id") or "")))
    return result


def due_reminders(channel_id: int, *, limit: int = 20) -> list[dict[str, Any]]:
    current = _now()
    return [
        row for row in list_reminders(include_done=False)
        if int(row.get("channel_id") or 0) == int(channel_id) and int(row.get("due_at") or 0) <= current
    ][:max(1, min(int(limit or 20), 100))]


def mark_reminder_delivered(reminder_id: str) -> bool:
    target = str(reminder_id or "").strip()
    with _LOCK:
        rows = _load()
        changed = False
        for row in rows:
            if str(row.get("id") or "") == target and not int(row.get("cancelled_at") or 0):
                row["delivered_at"] = _now()
                changed = True
                break
        if changed:
            _save(rows)
        return changed


def cancel_reminder(reminder_id: str, *, owner_id: int | None = None) -> bool:
    target = str(reminder_id or "").strip()
    with _LOCK:
        rows = _load()
        changed = False
        for row in rows:
            if str(row.get("id") or "") != target:
                continue
            if owner_id is not None and int(row.get("owner_id") or 0) != int(owner_id):
                continue
            if int(row.get("delivered_at") or 0) or int(row.get("cancelled_at") or 0):
                continue
            row["cancelled_at"] = _now()
            changed = True
            break
        if changed:
            _save(rows)
        return changed


def format_reminder_time(timestamp: int) -> str:
    return dt.datetime.fromtimestamp(int(timestamp)).astimezone().strftime("%a %b %d · %I:%M %p %Z")


__all__ = [
    "REMINDERS_PATH",
    "parse_reminder_when",
    "create_reminder",
    "create_reminder_from_text",
    "list_reminders",
    "due_reminders",
    "mark_reminder_delivered",
    "cancel_reminder",
    "format_reminder_time",
]
