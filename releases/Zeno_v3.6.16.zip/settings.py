#!/usr/bin/env python3
"""Thread-safe cached settings access for Zeno."""

from __future__ import annotations

import threading
import uuid
from typing import Final

from config import DEFAULT_COMPUTE_MODE, SUPPORTED_COMPUTE_MODES
from database import (
    current_chat_id,
    get_setting as db_get_setting,
    set_setting as db_set_setting,
)

_CACHE_LOCK = threading.RLock()
_MISSING: Final = object()
_MISSING_TOKEN = f"__ZENO_SETTING_MISSING_{uuid.uuid4().hex}__"
_SETTINGS_CACHE: dict[str, str | object] = {}

_HOT_SETTING_KEYS: tuple[str, ...] = (
    "personality",
    "model",
    "model_mode",
    "fast_model",
    "deep_model",
    "notetaker_model",
    "context_window_tokens",
    "use_browser",
    "include_page_screenshot",
    "memory_retrieval_enabled",
    "memory_retrieval_limit",
    "adaptive_context_enabled",
    "discord_browser_activity_mode",
    "discord_completion_mentions",
    "live_screen_enabled",
    "live_assist_interval_enabled",
    "live_assist_interval_seconds",
    "compute_mode",
    "gpu_offload_requested",
    "update_repo",
    "auto_update_check",
)

_VALID_MODEL_MODES = frozenset({"fast", "balanced", "deep"})
_VALID_COMPUTE_MODES = frozenset(str(mode).casefold() for mode in SUPPORTED_COMPUTE_MODES)


def _read_database_setting(key: str) -> str | object:
    """Read one setting while preserving the distinction between missing and empty."""
    value = db_get_setting(key, _MISSING_TOKEN)
    return _MISSING if value == _MISSING_TOKEN else str(value)


def _normalize_for_write(key: str, value: str) -> str:
    """Validate only settings whose accepted values are explicitly known."""
    key = str(key)
    text = str(value)

    if key == "model_mode":
        normalized = text.strip().casefold()
        if normalized not in _VALID_MODEL_MODES:
            raise ValueError("model_mode must be one of: fast, balanced, deep")
        return normalized

    if key == "compute_mode":
        normalized = text.strip().casefold()
        if normalized not in _VALID_COMPUTE_MODES:
            raise ValueError(
                "compute_mode must be one of: " + ", ".join(sorted(_VALID_COMPUTE_MODES))
            )
        return normalized

    if key == "gpu_offload_requested":
        normalized = text.strip()
        if not normalized:
            raise ValueError("gpu_offload_requested must be a non-empty text value")
        return normalized.casefold() if normalized.casefold() == "auto" else normalized

    # Preserve arbitrary/custom settings exactly as text for backward/forward compatibility.
    return text


def invalidate_setting(key: str) -> None:
    """Remove one cached entry without changing persistent storage."""
    with _CACHE_LOCK:
        _SETTINGS_CACHE.pop(str(key), None)


def clear_settings_cache() -> None:
    """Drop all cached setting values."""
    with _CACHE_LOCK:
        _SETTINGS_CACHE.clear()


def preload_settings(keys: list[str] | tuple[str, ...] | None = None) -> None:
    """Warm a conservative set of frequently-read settings.

    Database reads happen outside the cache lock so other threads are not blocked
    on SQLite I/O. Missing rows are cached as a dedicated sentinel, never as a
    caller-specific fallback.
    """
    requested = tuple(str(key) for key in (keys if keys is not None else _HOT_SETTING_KEYS))
    loaded: dict[str, str | object] = {}
    for key in requested:
        loaded[key] = _read_database_setting(key)
    with _CACHE_LOCK:
        _SETTINGS_CACHE.update(loaded)


def settings_cache_status() -> dict[str, object]:
    """Return lightweight cache diagnostics without exposing setting values."""
    with _CACHE_LOCK:
        keys = sorted(_SETTINGS_CACHE)
        missing = sorted(key for key, value in _SETTINGS_CACHE.items() if value is _MISSING)
    return {
        "size": len(keys),
        "keys": keys,
        "missing_keys": missing,
        "hot_keys": list(_HOT_SETTING_KEYS),
    }


def get_setting(key: str, fallback: str = "", *, force_refresh: bool = False) -> str:
    """Return a persisted setting with thread-safe lazy caching.

    Missing settings are represented separately from stored empty strings, so
    each caller's fallback remains meaningful even after the miss is cached.
    """
    key = str(key)

    if not force_refresh:
        with _CACHE_LOCK:
            cached = _SETTINGS_CACHE.get(key, None)
            cache_hit = key in _SETTINGS_CACHE
        if cache_hit:
            return fallback if cached is _MISSING else str(cached)

    # Do SQLite I/O without holding the cache lock.
    fresh = _read_database_setting(key)
    with _CACHE_LOCK:
        _SETTINGS_CACHE[key] = fresh
    return fallback if fresh is _MISSING else str(fresh)


def bool_setting(key: str, fallback: bool = False, *, force_refresh: bool = False) -> bool:
    """Return True only when the stored text casefolds exactly to 'true'."""
    value = get_setting(
        key,
        "true" if fallback else "false",
        force_refresh=force_refresh,
    )
    return value.casefold() == "true"


def int_setting(
    key: str,
    fallback: int,
    minimum: int,
    maximum: int,
    *,
    force_refresh: bool = False,
) -> int:
    """Parse an integer setting, fall back on invalid text, and clamp the result."""
    if minimum > maximum:
        raise ValueError("minimum cannot be greater than maximum")
    try:
        value = int(get_setting(key, str(fallback), force_refresh=force_refresh))
    except ValueError:
        value = int(fallback)
    return max(int(minimum), min(value, int(maximum)))


def set_setting(key: str, value: str) -> None:
    """Persist a setting first, then update the cache after the write succeeds."""
    key = str(key)
    normalized = _normalize_for_write(key, value)

    # Persistence errors deliberately propagate. Do not make the cache claim a
    # value was saved when SQLite rejected the write.
    db_set_setting(key, normalized)

    with _CACHE_LOCK:
        _SETTINGS_CACHE[key] = normalized


def model_mode_setting(fallback: str = "balanced") -> str:
    """Return a safe Fast/Balanced/Deep mode without performing model routing."""
    fallback_normalized = str(fallback).strip().casefold()
    if fallback_normalized not in _VALID_MODEL_MODES:
        fallback_normalized = "balanced"
    value = get_setting("model_mode", fallback_normalized).strip().casefold()
    return value if value in _VALID_MODEL_MODES else fallback_normalized


def compute_mode_setting(fallback: str = DEFAULT_COMPUTE_MODE) -> str:
    """Return a safe compute placement mode without changing model selection."""
    fallback_normalized = str(fallback).strip().casefold()
    if fallback_normalized not in _VALID_COMPUTE_MODES:
        fallback_normalized = str(DEFAULT_COMPUTE_MODE).casefold()
    value = get_setting("compute_mode", fallback_normalized).strip().casefold()
    return value if value in _VALID_COMPUTE_MODES else fallback_normalized


__all__ = [
    "get_setting",
    "bool_setting",
    "int_setting",
    "set_setting",
    "invalidate_setting",
    "clear_settings_cache",
    "preload_settings",
    "settings_cache_status",
    "model_mode_setting",
    "compute_mode_setting",
    "current_chat_id",
]
