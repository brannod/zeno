#!/usr/bin/env python3
"""Deterministic task routing for explicit Zeno tool intents.

The router deliberately defaults to normal chat. It only takes control when the
user clearly asks for a tool action, preventing ordinary questions from being
accidentally launched as Browser Agent jobs.
"""
from __future__ import annotations

import re
from typing import Any


def route_task(text: str) -> dict[str, Any]:
    raw = re.sub(r"\s+", " ", str(text or "")).strip()
    value = raw.casefold()
    if not raw:
        return {"kind": "chat", "confidence": 0.0, "reason": "empty"}

    if re.match(r"^remind\s+me\b", value):
        return {"kind": "reminder", "confidence": 0.99, "reason": "explicit reminder language"}

    if re.search(r"\b(optimi[sz]e|clean\s*up|dedupe|de-duplicate|merge duplicates?)\b.{0,30}\bmemor(?:y|ies)\b", value) or re.search(r"\bmemor(?:y|ies)\b.{0,30}\b(optimi[sz]e|dedupe|merge duplicates?)\b", value):
        return {"kind": "memory_optimize", "confidence": 0.96, "reason": "explicit memory maintenance request"}

    file_words = bool(re.search(r"\b(my\s+)?(files?|uploads?|documents?|attachments?)\b", value))
    search_words = bool(re.search(r"\b(find|search|look\s+for|locate|scan|check)\b", value))
    if file_words and search_words:
        query = re.sub(r"(?i)\b(?:in|through|across)\s+(?:all\s+)?(?:my\s+)?(?:files?|uploads?|documents?|attachments?)\b", "", raw).strip()
        query = re.sub(r"(?i)^(?:find|search(?:\s+for)?|look\s+for|locate|scan|check)\s+", "", query).strip()
        return {"kind": "file_search", "confidence": 0.94, "reason": "explicit local-file search", "query": query or raw}

    explicit_browser = bool(re.search(r"\b(browser agent|use (?:the )?browser|open (?:the )?browser|browse (?:the )?(?:web|site|website)|in (?:the )?browser)\b", value))
    url_action = bool(re.search(r"https?://\S+", raw)) and bool(re.search(r"\b(open|go|visit|browse|check|find|look|search|read|compare)\b", value))
    site_action = bool(re.search(r"^(?:zeno\s+)?(?:go\s+(?:on|to)|visit|open|browse|check)\s+", value)) and bool(re.search(r"\b(site|website|page|github|google|discord|reddit|amazon|best buy|walmart|ebay)\b|https?://", value))
    if explicit_browser or url_action or site_action:
        return {"kind": "browser_agent", "confidence": 0.93 if explicit_browser else 0.86, "reason": "explicit browser action", "goal": raw}

    return {"kind": "chat", "confidence": 0.0, "reason": "normal conversation"}


__all__ = ["route_task"]
